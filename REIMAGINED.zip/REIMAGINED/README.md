# REIMAGINED

A two-player local game that brings classic Filipino street games to the screen, built with Python and Pygame.

## Game modes

| Mode | Player 1 (WASD) | Player 2 (Arrow keys) | How to win |
|------|-----------------|-----------------------|------------|
| **Tumbang Preso** | Move, hold `E` to aim and release to throw the tsinelas (slipper), `Q` to feint | Guards the can and blocks throws | P1 knocks the can down, or P2 survives until time runs out |
| **Habulan** | Runner: move, `E` to stun the chaser | Chaser: tag the runner | Chaser tags the runner, or the runner survives 60 seconds |

Menu flow: Start screen → Game mode → Character select → Map select → Game.
Every screen has a **Back** button. Press `ESC` to quit a match, and `R` on the win screen to restart.

## Getting started

Requires Python 3.10 or newer.

```bash
git clone https://github.com/<your-username>/REIMAGINED.git
cd REIMAGINED

python -m venv .venv
source .venv/bin/activate      # Windows: .venv\Scripts\activate

pip install -r requirements.txt
python main.py
```

The game starts in fullscreen.

## Project structure

```
REIMAGINED/
├── main.py                 # Entry point and screen flow
├── requirements.txt
├── game/
│   ├── assets.py           # Finds asset files by name
│   ├── sound.py            # Music and sound effects
│   ├── sprites.py          # Sprite loading and animators
│   ├── pregame.py          # Start screen and character select
│   ├── gamemode_select.py  # Game mode picker
│   ├── design.py           # Map selection
│   ├── back_button.py      # Reusable Back button
│   ├── credits.py          # Scrolling credits
│   ├── habulan.py          # Habulan game mode
│   └── tumbang_preso.py    # Tumbang Preso game mode
└── assets/
    ├── images/             # backgrounds, countdown, UI
    ├── sprites/            # characters, heads, items
    ├── audio/              # music, sfx
    └── _unused/            # files not referenced by the code
```

## Adding assets

Drop a file anywhere inside `assets/` (outside `_unused/`) and load it by file name:

```python
from game.assets import asset
image = pygame.image.load(asset("my_sprite.png"))
```

File names must be unique across the `assets/` folders.
