import pygame
import sys
from game.pregame import start_screen, pregame_screen
from game.sound import play_pregame_music
from game.gamemode_select import gamemode_select
from game.habulan import run_habulan
from game.tumbang_preso import run_tumbang_preso


# =============================================================================
# MAIN
# Flow: Start screen → Game Mode Select → Character Select → Map Select → Game
#       Back button on any screen returns to the previous screen.
# =============================================================================

def main():
    pygame.init()
    screen = pygame.display.set_mode((0, 0), pygame.FULLSCREEN)
    pygame.display.set_caption("Reimagined")
    clock = pygame.time.Clock()

    play_pregame_music()

    while True:
        # ── 1. Start screen (title / main menu) ──────────────────────────────
        start_screen(screen)

        # ── 2. Game Mode Selection ────────────────────────────────────────────
        selected_mode = gamemode_select(screen)
        if selected_mode == "back":
            # Back on mode select → return to start screen
            continue

        # ── 3. Character Select ───────────────────────────────────────────────
        result = pregame_screen(screen)
        if result == "back":
            # Back on character select → return to mode select
            selected_mode = gamemode_select(screen)
            if selected_mode == "back":
                continue  # back again → start screen
            result = pregame_screen(screen)
            if result == "back":
                continue
        p1_name, p2_name, p1_char_idx, p2_char_idx = result

        # ── 4. Route to chosen game mode ──────────────────────────────────────
        if selected_mode == "habulan":
            run_habulan(screen, clock, p1_name, p2_name, p1_char_idx, p2_char_idx)
        else:
            run_tumbang_preso(screen, clock, p1_name, p2_name, p1_char_idx, p2_char_idx)

        # After a game ends, loop back to the start screen
        play_pregame_music()


if __name__ == "__main__":
    main()
