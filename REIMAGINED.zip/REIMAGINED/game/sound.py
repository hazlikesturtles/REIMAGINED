# =============================================================================
#  sound.py — Audio Manager
#  Reimagined | Filipino Street Games
# =============================================================================
#
#  Handles all music and sound effects in the game.
#
#  MUSIC TRACKS:
#    - Pregame / menus     → pregame_background_music.mp3  (loops forever)
#    - In-game             → maingame_music.mp3            (loops forever)
#    - Countdown (3-2-1)   → 3_2_1_go_Green_screen_footage.mp3 (plays once)
#
#  SOUND EFFECTS:
#    - Tsinelas throw      → 7 random whoosh variants (.wav)
#
# =============================================================================

import pygame
import random
from .assets import asset


# ── Audio file paths ──────────────────────────────────────────────────────────

PREGAME_MUSIC   = "pregame_background_music.mp3"
MAINGAME_MUSIC  = "maingame_music.mp3"
COUNTDOWN_AUDIO = "3_2_1_go_Green_screen_footage.mp3"

# 7 whoosh variants — a random one plays each time the slipper is thrown
# so it never sounds repetitive
TSINELAS_SFX_FILES = [
    "tsinelas_throw_1.wav",
    "tsinelas_throw_2.wav",
    "tsinelas_throw_3.wav",
    "tsinelas_throw_4.wav",
    "tsinelas_throw_5.wav",
    "tsinelas_throw_6.wav",
    "tsinelas_throw_7.wav",
]

# Cache for loaded Sound objects — filled on first throw, never reloaded
_tsinelas_sfx_cache = []


# ── Internal helper ───────────────────────────────────────────────────────────

def _init_mixer():
    """Initialise the pygame mixer once. Safe to call multiple times."""
    if not pygame.mixer.get_init():
        pygame.mixer.init()


# ── Music functions ───────────────────────────────────────────────────────────

def play_pregame_music():
    """
    Plays the menu / character-select background music on an infinite loop.
    Call this on the Start Screen and again after a game session ends.
    """
    _init_mixer()
    try:
        pygame.mixer.music.load(asset(PREGAME_MUSIC))
        pygame.mixer.music.play(loops=-1)   # -1 = loop forever
    except Exception as e:
        print(f"[sound] Warning – pregame music not loaded: {e}")


def play_maingame_music():
    """
    Stops whatever is playing and starts the in-game music on an infinite loop.
    Call this right after the countdown finishes (when the match begins).
    """
    _init_mixer()
    try:
        pygame.mixer.music.stop()
        pygame.mixer.music.load(asset(MAINGAME_MUSIC))
        pygame.mixer.music.play(loops=-1)   # -1 = loop forever
    except Exception as e:
        print(f"[sound] Warning – maingame music not loaded: {e}")


def stop_music():
    """Stops any currently playing music track."""
    if pygame.mixer.get_init():
        pygame.mixer.music.stop()


# ── Countdown audio ───────────────────────────────────────────────────────────

def play_countdown_audio():
    """
    Stops the current BGM and plays the 3-2-1-GO! audio clip once.
    The in-game music is started separately after this finishes.
    """
    _init_mixer()
    try:
        pygame.mixer.music.stop()
        pygame.mixer.music.load(asset(COUNTDOWN_AUDIO))
        pygame.mixer.music.play()           # plays once, no loop
    except Exception as e:
        print(f"[sound] Warning – countdown audio not loaded: {e}")


# ── Tsinelas throw SFX ────────────────────────────────────────────────────────

def _load_tsinelas_sfx():
    """
    Loads all tsinelas whoosh variants into the cache.
    Only runs once — subsequent calls do nothing.
    """
    global _tsinelas_sfx_cache
    if _tsinelas_sfx_cache:
        return                              # already loaded, skip
    _init_mixer()
    for path in TSINELAS_SFX_FILES:
        try:
            _tsinelas_sfx_cache.append(pygame.mixer.Sound(asset(path)))
        except Exception as e:
            print(f"[sound] Warning – {path} not loaded: {e}")


def play_tsinelas_throw():
    """
    Plays a random whoosh sound effect when Player 1 throws the slipper.
    Picks from 7 variants so it never sounds the same twice in a row.
    """
    _load_tsinelas_sfx()
    if _tsinelas_sfx_cache:
        random.choice(_tsinelas_sfx_cache).play()
