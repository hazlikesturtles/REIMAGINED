
import pygame


class BackButton:
    """
    Draws a '← Back' button in the top-left corner and detects clicks.
    Consistent size, style, and position across every screen.
    """

    PAD_X  = 16   # distance from left edge
    PAD_Y  = 14   # distance from top edge
    BTN_W  = 90
    BTN_H  = 34

    # Colours
    COL_NORMAL  = (45,  38,  65)
    COL_HOVER   = (70,  58, 100)
    COL_BORDER  = (160, 140, 200)
    COL_TEXT    = (220, 215, 240)
    COL_ARROW   = (200, 180, 255)

    def __init__(self, screen):
        W, H = screen.get_size()
        self.rect = pygame.Rect(self.PAD_X, self.PAD_Y, self.BTN_W, self.BTN_H)
        self.font = pygame.font.SysFont("Arial", max(14, H // 48), bold=True)
        self._hovered = False

    def draw(self, screen):
        mx, my = pygame.mouse.get_pos()
        self._hovered = self.rect.collidepoint(mx, my)

        # Background
        bg_col = self.COL_HOVER if self._hovered else self.COL_NORMAL
        surf = pygame.Surface((self.rect.width, self.rect.height), pygame.SRCALPHA)
        pygame.draw.rect(surf, (*bg_col, 210), (0, 0, self.rect.width, self.rect.height),
                         border_radius=7)
        screen.blit(surf, self.rect.topleft)

        # Border
        pygame.draw.rect(screen, self.COL_BORDER, self.rect, 1, border_radius=7)

        # Label
        label = self.font.render("← Back", True, self.COL_TEXT)
        screen.blit(label, (
            self.rect.centerx - label.get_width() // 2,
            self.rect.centery - label.get_height() // 2,
        ))

    def clicked(self, event):
        """Returns True if the given event is a left-click on the button."""
        return (
            event.type == pygame.MOUSEBUTTONDOWN
            and event.button == 1
            and self.rect.collidepoint(event.pos)
        )
