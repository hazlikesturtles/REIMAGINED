# =============================================================================
#  habulan.py — Habulan (Tag) Game Mode
#  Reimagined | Filipino Street Games
# =============================================================================
#
#  RULES:
#    - Player 1 = RUNNER  — survives by avoiding the Chaser for 60 seconds
#    - Player 2 = CHASER  — wins by touching the Runner before time runs out
#
#  CONTROLS:
#    Player 1 (Runner)  →  WASD to move  |  E to throw Tsinelas
#    Player 2 (Chaser)  →  Arrow keys to move
#
#  TSINELAS ABILITY (Runner only):
#    - Press E to throw the slipper toward the Chaser
#    - Direct hit stuns the Chaser for 3 seconds (frozen in place)
#    - 5-second cooldown after each throw (shown as a bar in the HUD)
#
#  WIN CONDITIONS:
#    - Chaser wins  → touches the Runner (when Chaser is not stunned)
#    - Runner wins  → survives the full 60 seconds
#
#  ENTRY POINT:
#    run_habulan(screen, clock, p1_name, p2_name, p1_char_idx, p2_char_idx)
#
# =============================================================================

import pygame
import sys
import math

from .sprites import RunnerAnimator, Player2Animator, Tsinelas, draw_sprite
from .pregame import CHARACTERS
from .sound import play_countdown_audio, play_maingame_music, play_tsinelas_throw
from .assets import asset


# =============================================================================
#  CONSTANTS
# =============================================================================

FPS          = 60             # frames per second target
GAME_SECONDS = 60             # how long the Runner must survive to win
SPEED        = 5              # player movement speed (pixels per frame)
HIT_BOX_FRAC = 0.55           # hitboxes are 55% of sprite size (forgiving collisions)

TSINELAS_CD    = 7  * FPS     # 7-second cooldown between throws (in frames)
TSINELAS_SPEED = 12           # slipper travel speed (pixels per frame)
TSINELAS_STUN  = 2  * FPS     # 2-second freeze on Chaser after a hit (in frames)

# The only available map in Habulan
GRASS_MAP = {
    "name":           "Grass",
    "file":           "grass.png",
    "top_constraint": 0,              # no top boundary restriction
    "barrier_color":  (255, 255, 255),
}

# HUD label colors
RUNNER_LABEL_COLOR = ( 80, 200,  80)   # green  — Runner role label
CHASER_LABEL_COLOR = (255,  80,  80)   # red    — Chaser role label
TIMER_WARN_COLOR   = (255,  60,  60)   # red    — countdown timer in last 10 seconds
TIMER_NORMAL_COLOR = (255, 255, 255)   # white  — countdown timer (normal)
CD_READY_COLOR     = ( 50, 200, 255)   # cyan   — cooldown bar when throw is ready
CD_WAIT_COLOR      = (100, 120, 200)   # purple — cooldown bar while waiting

# Countdown display: image filenames and how many frames each one shows
COUNTDOWN_IMAGES = ["2.png", "3.png", "4.png", "5.png"]
STEP_DURATIONS   = [60, 60, 60, 48]


# =============================================================================
#  BACKGROUND BLUR HELPER
# =============================================================================

def _make_blurred_bg(surface, W, H):
    """
    Creates a blurred version of any surface by drastically downscaling
    then upscaling it. Used as the backdrop for the countdown and win screens.
    Also applies a dark overlay to keep text readable.
    """
    try:
        src = surface.convert()
    except Exception:
        src = surface

    small   = pygame.transform.smoothscale(src, (max(1, W // 10), max(1, H // 10)))
    blurred = pygame.transform.smoothscale(small, (W, H))

    dark = pygame.Surface((W, H), pygame.SRCALPHA)
    dark.fill((0, 0, 0, 120))
    blurred.blit(dark, (0, 0))
    return blurred


# =============================================================================
#  COUNTDOWN ANIMATION
# =============================================================================

def _load_countdown_frames(H):
    """
    Loads the 3-2-1-GO! countdown images and scales them to 65% of screen height.
    Returns (frames_list, size_tuple).
    """
    size   = (int(H * 0.65), int(H * 0.65))
    frames = []
    for path in COUNTDOWN_IMAGES:
        try:
            img = pygame.image.load(asset(path)).convert()
            img.set_colorkey((0, 0, 0))     # remove black background from image
            frames.append(pygame.transform.smoothscale(img, size))
        except Exception as e:
            print(f"[habulan] Could not load {path}: {e}")
            frames.append(None)
    return frames, size


def _bake_pop_frames(frames, size, levels=8):
    """
    Pre-renders each countdown image at 8 zoom levels (100% to 135% scale).
    This creates the "pop-in" animation effect without scaling inside the draw loop.
    """
    baked = []
    for img in frames:
        zooms = []
        for lvl in range(levels):
            scale = 1.0 + 0.35 * (lvl / (levels - 1))
            if img:
                w = int(size[0] * scale)
                h = int(size[1] * scale)
                zooms.append(pygame.transform.smoothscale(img, (max(1, w), max(1, h))))
            else:
                zooms.append(None)
        baked.append(zooms)
    return baked


def _play_countdown(screen, clock, map_surface=None):
    """
    Plays the 3-2-1-GO! countdown animation fullscreen over a blurred map.
    Blocks until the animation fully completes, then returns.
    Also triggers the countdown audio clip.
    """
    W, H = screen.get_size()
    blurred_bg   = _make_blurred_bg(map_surface, W, H) if map_surface else None
    frames, size = _load_countdown_frames(H)
    baked        = _bake_pop_frames(frames, size)

    play_countdown_audio()

    step       = 0
    step_timer = 0

    while step < len(frames):
        clock.tick(60)

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit(); sys.exit()
            if event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE:
                pygame.quit(); sys.exit()

        # progress goes from 0.0 to 1.0 across the current step
        progress = step_timer / STEP_DURATIONS[step]

        # Fade out during the final 25% of each step
        fade_alpha = 255 if progress <= 0.75 else int(255 * (1.0 - (progress - 0.75) / 0.25))

        # Pop-in: starts large and shrinks to normal size during the first 25%
        pop_level = int(max(0.0, 1.0 - progress * 4) * 7)

        screen.blit(blurred_bg, (0, 0)) if blurred_bg else screen.fill((20, 20, 35))

        img = baked[step][pop_level]
        if img:
            img.set_alpha(fade_alpha)
            screen.blit(img, (W // 2 - img.get_width() // 2, H // 2 - img.get_height() // 2))

        pygame.display.flip()

        step_timer += 1
        if step_timer >= STEP_DURATIONS[step]:
            step      += 1
            step_timer = 0


# =============================================================================
#  COLLISION HELPER
# =============================================================================

def _rects_overlap(ax, ay, aw, ah, bx, by, bw, bh):
    """
    AABB (axis-aligned bounding box) collision check using center positions.
    aw/ah and bw/bh are half-sizes.
    Returns True if the two rectangles overlap.
    """
    return abs(ax - bx) < (aw + bw) and abs(ay - by) < (ah + bh)


# =============================================================================
#  MOVEMENT HELPER
# =============================================================================

def _move(keys, x, y, hw, hh, speed, left_wall, right_wall, top_wall, bottom_wall,
          up_k, down_k, left_k, right_k, stunned=False):
    """
    Moves a player according to key input, clamped within the given boundaries.

    hw, hh   — sprite half-width / half-height (so edges don't go past walls)
    stunned  — if True, no movement is applied (used for the Chaser when hit)
    """
    if stunned:
        return x, y     # frozen — no movement allowed

    if keys[up_k]:    y -= speed
    if keys[down_k]:  y += speed
    if keys[left_k]:  x -= speed
    if keys[right_k]: x += speed

    # Keep within screen bounds
    x = max(left_wall  + hw, min(right_wall  - hw, x))
    y = max(top_wall   + hh, min(bottom_wall - hh, y))
    return x, y


# =============================================================================
#  MAP SELECTION SCREEN  (Habulan — single map only)
# =============================================================================

def habulan_map_selection(screen, clock):
    """
    Displays the map picker for Habulan.
    Only the Grass map is available — the player just clicks to confirm.

    Returns: (map_surface, top_constraint_fraction, barrier_color)
    """
    pygame.font.init()
    W, H = screen.get_size()

    font_title = pygame.font.Font(None, max(36, H // 18))
    font_label = pygame.font.Font(None, max(20, H // 35))

    # ── Blurred background ────────────────────────────────────────────────────
    try:
        _bg        = pygame.image.load(asset("background_start.png")).convert()
        _bg        = pygame.transform.smoothscale(_bg, (W, H))
        _small     = pygame.transform.smoothscale(_bg, (W // 8, H // 8))
        blurred_bg = pygame.transform.smoothscale(_small, (W, H))
        dark       = pygame.Surface((W, H))
        dark.fill((0, 0, 0))
        dark.set_alpha(90)
        blurred_bg.blit(dark, (0, 0))
    except Exception:
        blurred_bg = None

    # ── Single map thumbnail card ─────────────────────────────────────────────
    THUMB_W = 220
    THUMB_H = 145
    LABEL_H = 38

    try:
        raw_thumb = pygame.image.load(asset(GRASS_MAP["file"])).convert()
        thumb     = pygame.transform.smoothscale(raw_thumb, (THUMB_W, THUMB_H))
    except Exception:
        thumb = pygame.Surface((THUMB_W, THUMB_H))
        thumb.fill((100, 180, 80))  # green placeholder if image is missing

    # Center the card on screen
    card_x    = W // 2 - THUMB_W // 2
    card_y    = H // 2 - (THUMB_H + LABEL_H) // 2
    card_rect = pygame.Rect(card_x, card_y, THUMB_W, THUMB_H + LABEL_H)

    title_surf = font_title.render("Pick a Map", True, (255, 255, 255))
    title_rect = title_surf.get_rect(center=(W // 2, H // 4))

    # ── Wait for a click on the card ──────────────────────────────────────────
    selected = None
    while selected is None:
        clock.tick(60)

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit(); sys.exit()
            if event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE:
                pygame.quit(); sys.exit()
            if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                if card_rect.collidepoint(event.pos):
                    selected = True

        mx, my   = pygame.mouse.get_pos()
        hovering = card_rect.collidepoint(mx, my)

        # Draw
        screen.blit(blurred_bg, (0, 0)) if blurred_bg else screen.fill((30, 30, 50))
        screen.blit(title_surf, title_rect)

        # Thumbnail
        screen.set_clip(pygame.Rect(card_x, card_y, THUMB_W, THUMB_H))
        screen.blit(thumb, (card_x, card_y))
        screen.set_clip(None)

        # Label strip below thumbnail
        lbl_bg = pygame.Surface((THUMB_W, LABEL_H), pygame.SRCALPHA)
        lbl_bg.fill((0, 0, 0, 150))
        screen.blit(lbl_bg, (card_x, card_y + THUMB_H))
        lbl = font_label.render(GRASS_MAP["name"], True, (255, 255, 255))
        screen.blit(lbl, (
            card_x + THUMB_W // 2 - lbl.get_width() // 2,
            card_y + THUMB_H + (LABEL_H - lbl.get_height()) // 2,
        ))

        # Card border — brighter on hover
        border_col = (255, 255, 255) if hovering else (200, 200, 200)
        pygame.draw.rect(screen, border_col, card_rect, 2 if hovering else 1)
        pygame.display.flip()

    # Load and return the full-resolution map surface
    try:
        map_surf = pygame.image.load(asset(GRASS_MAP["file"])).convert()
        map_surf = pygame.transform.smoothscale(map_surf, (W, H))
    except Exception:
        map_surf = pygame.Surface((W, H))
        map_surf.fill((100, 180, 80))

    return map_surf, GRASS_MAP["top_constraint"], GRASS_MAP["barrier_color"]


# =============================================================================
#  WIN SCREEN
# =============================================================================

def _draw_win_screen(screen, font_big, font_small, frame, winner_name, role_label, blurred_bg=None):
    """
    Draws the win screen over the map.

    winner_name  — the player's name (from character select)
    role_label   — "Chaser" or "Runner — survived!"
    frame        — elapsed frames since win (drives the pulsing scale effect)
    """
    W, H = screen.get_size()

    screen.blit(blurred_bg, (0, 0)) if blurred_bg else screen.fill((10, 10, 25))

    # Dark overlay for readability
    overlay = pygame.Surface((W, H), pygame.SRCALPHA)
    overlay.fill((0, 0, 0, 150))
    screen.blit(overlay, (0, 0))

    # Winner name — slowly pulses in size using a sine wave
    scale = 1.0 + 0.06 * math.sin(frame * 0.1)
    text  = font_big.render(f"{winner_name} Wins!", True, (255, 220, 0))
    tw    = int(text.get_width()  * scale)
    th    = int(text.get_height() * scale)
    screen.blit(pygame.transform.smoothscale(text, (tw, th)),
                (W // 2 - tw // 2, H // 2 - th // 2 - 50))

    # Role label (e.g. "Chaser" or "Runner — survived!")
    role = font_small.render(f"({role_label})", True, (200, 200, 200))
    screen.blit(role, (W // 2 - role.get_width() // 2, H // 2 - th // 2 + 10))

    # Restart / back instructions
    sub = font_small.render("Press R to restart  |  ESC to go back", True, (220, 220, 220))
    screen.blit(sub, (W // 2 - sub.get_width() // 2, H // 2 + th // 2 + 20))


# =============================================================================
#  COOLDOWN BAR
# =============================================================================

def _draw_cd_bar(screen, font, cd, cd_max, label, bar_x, bar_y, bar_w=130, bar_h=14):
    """
    Draws a horizontal cooldown bar with a text label above it.

    cd      — remaining cooldown frames (0 = ability is ready)
    cd_max  — total cooldown frames (used to calculate the fill ratio)
    label   — text shown above the bar (e.g. "E  Tsinelas")
    """
    fill      = int(bar_w * (1.0 - cd / cd_max)) if cd_max > 0 else bar_w
    bar_color = CD_READY_COLOR if cd == 0 else CD_WAIT_COLOR

    pygame.draw.rect(screen, (180, 180, 180), (bar_x, bar_y, bar_w, bar_h))  # track
    pygame.draw.rect(screen, bar_color,       (bar_x, bar_y, fill,  bar_h))  # fill
    pygame.draw.rect(screen, (0, 0, 0),       (bar_x, bar_y, bar_w, bar_h), 1)  # border

    # Append "READY!" text when the ability can be used
    ready_str = "  READY!" if cd == 0 else ""
    lbl = font.render(label + ready_str, True, (255, 255, 255))
    screen.blit(lbl, (bar_x, bar_y - lbl.get_height() - 2))


# =============================================================================
#  MAIN ENTRY POINT
# =============================================================================

def run_habulan(screen, clock, p1_name, p2_name, p1_char_idx, p2_char_idx):
    """
    Runs the complete Habulan game loop.

    Called by main.py after character select.
    Returns when ESC is pressed (goes back to main menu).
    Press R on the win screen to restart the match.
    """
    pygame.font.init()
    W, H = screen.get_size()

    font_big   = pygame.font.Font(None, max(56, H // 12))
    font_small = pygame.font.Font(None, max(26, H // 28))
    font_hud   = pygame.font.Font(None, max(22, H // 34))

    # ── Map setup ─────────────────────────────────────────────────────────────
    map_surface, top_frac, _ = habulan_map_selection(screen, clock)
    blurred_win_bg = _make_blurred_bg(map_surface, W, H)
    top_y          = int(H * top_frac)   # pixel row players cannot walk above

    # ── Countdown then game music ─────────────────────────────────────────────
    _play_countdown(screen, clock, map_surface=map_surface)
    play_maingame_music()

    SPRITE_SCALE = (96, 96)   # all character sprites rendered at this size

    # ── Animator factory ──────────────────────────────────────────────────────
    def _make_animators():
        """Creates fresh animators for both players using their chosen characters."""
        p1_char = CHARACTERS[p1_char_idx]
        p2_char = CHARACTERS[p2_char_idx]
        p1_anim = RunnerAnimator(scale=SPRITE_SCALE, sprites=p1_char["sprites_p1"])
        p2_anim = Player2Animator(scale=SPRITE_SCALE, sprites=p2_char["sprites_p2"])
        return p1_anim, p2_anim

    # ── Game state factory ────────────────────────────────────────────────────
    def reset_game():
        """
        Builds and returns a fresh game-state dictionary.
        Called at match start and whenever R is pressed on the win screen.
        """
        p1_anim, p2_anim = _make_animators()
        sw1, sh1 = p1_anim.get_size()
        sw2, sh2 = p2_anim.get_size()
        mid_y    = top_y + (H - top_y) // 2   # vertical center of the playable zone

        return {
            # Character animators
            "p1_anim": p1_anim,
            "p2_anim": p2_anim,

            # Sprite half-sizes (used for hitbox calculations)
            "hw1": sw1 // 2, "hh1": sh1 // 2,
            "hw2": sw2 // 2, "hh2": sh2 // 2,

            # Starting positions (Runner left, Chaser right)
            "x1": int(W * 0.20), "y1": mid_y,
            "x2": int(W * 0.80), "y2": mid_y,

            # Match timer
            "timer_frames": GAME_SECONDS * FPS,

            # Win condition flags
            "chaser_wins": False,
            "runner_wins": False,
            "win_frame":   0,     # frames elapsed since win (for pulse animation)

            # Visual flash effects
            "catch_flash": 0,     # full-screen red flash on tag
            "throw_flash": 0,     # cyan burst on Runner when throwing
            "stun_flash":  0,     # yellow burst on Chaser when hit

            # Tsinelas throw ability
            "tsinelas_cd":   0,   # cooldown frames remaining (0 = ready to throw)
            "tsinelas_list": [],  # list of active Tsinelas projectile objects
            "stun_timer":    0,   # frames the Chaser remains stunned
        }

    gs = reset_game()

    # ── Main game loop ────────────────────────────────────────────────────────
    running = True
    while running:
        clock.tick(FPS)
        keys = pygame.key.get_pressed()

        # ── Event handling ────────────────────────────────────────────────────
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False

            if event.type == pygame.KEYDOWN:

                if event.key == pygame.K_ESCAPE:
                    return  # exit to main menu

                # R restarts the match from the win screen
                if event.key == pygame.K_r and (gs["chaser_wins"] or gs["runner_wins"]):
                    gs = reset_game()
                    _play_countdown(screen, clock, map_surface=map_surface)
                    play_maingame_music()

                # E throws a Tsinelas toward the Chaser (if cooldown is ready)
                if (event.key == pygame.K_e
                        and not gs["chaser_wins"] and not gs["runner_wins"]
                        and gs["tsinelas_cd"] == 0):

                    # Direction vector from Runner to Chaser
                    dx   = gs["x2"] - gs["x1"]
                    dy   = gs["y2"] - gs["y1"]
                    dist = math.hypot(dx, dy) or 1   # guard against zero distance
                    vx   = (dx / dist) * TSINELAS_SPEED
                    vy   = (dy / dist) * TSINELAS_SPEED

                    # Spawn slipper at Runner's position
                    gs["tsinelas_list"].append(
                        Tsinelas(gs["x1"], gs["y1"], vx, vy, scale=(40, 40))
                    )
                    gs["tsinelas_cd"] = TSINELAS_CD   # start the cooldown
                    gs["p1_anim"].trigger_throw()     # show throw animation
                    gs["throw_flash"] = 10            # cyan burst effect
                    play_tsinelas_throw()             # whoosh sound effect

        # ── Logic update (only while the match is active) ─────────────────────
        if not gs["chaser_wins"] and not gs["runner_wins"]:

            # Advance animator states
            gs["p1_anim"].update(keys)
            gs["p2_anim"].update(keys)

            # Tick down all timers
            if gs["tsinelas_cd"] > 0: gs["tsinelas_cd"] -= 1
            if gs["stun_timer"]  > 0: gs["stun_timer"]  -= 1
            if gs["throw_flash"] > 0: gs["throw_flash"] -= 1
            if gs["stun_flash"]  > 0: gs["stun_flash"]  -= 1

            # Move Runner (WASD) — never stunned
            gs["x1"], gs["y1"] = _move(
                keys, gs["x1"], gs["y1"], gs["hw1"], gs["hh1"], SPEED,
                0, W, top_y, H,
                pygame.K_w, pygame.K_s, pygame.K_a, pygame.K_d,
            )

            # Move Chaser (Arrow keys) — frozen while stun_timer > 0
            gs["x2"], gs["y2"] = _move(
                keys, gs["x2"], gs["y2"], gs["hw2"], gs["hh2"], SPEED,
                0, W, top_y, H,
                pygame.K_UP, pygame.K_DOWN, pygame.K_LEFT, pygame.K_RIGHT,
                stunned=(gs["stun_timer"] > 0),
            )

            # Update slipper projectiles and check for hits
            to_remove = []
            for i, ts in enumerate(gs["tsinelas_list"]):
                ts.update()

                if ts.off_screen(W, H):
                    to_remove.append(i)
                    continue

                # Check if this slipper hit the Chaser
                if _rects_overlap(
                    ts.x, ts.y, 20, 20,
                    gs["x2"], gs["y2"],
                    gs["hw2"] * HIT_BOX_FRAC, gs["hh2"] * HIT_BOX_FRAC,
                ):
                    gs["stun_timer"] = TSINELAS_STUN   # stun the Chaser
                    gs["stun_flash"] = 20              # yellow burst effect
                    to_remove.append(i)

            # Remove used/off-screen slippers (reverse order to preserve indices)
            for i in sorted(set(to_remove), reverse=True):
                gs["tsinelas_list"].pop(i)

            # Check for tag — only valid when the Chaser is not stunned
            if gs["stun_timer"] == 0 and _rects_overlap(
                gs["x1"], gs["y1"], gs["hw1"] * HIT_BOX_FRAC, gs["hh1"] * HIT_BOX_FRAC,
                gs["x2"], gs["y2"], gs["hw2"] * HIT_BOX_FRAC, gs["hh2"] * HIT_BOX_FRAC,
            ):
                gs["chaser_wins"] = True
                gs["catch_flash"] = 30   # red screen flash

            # Tick match timer — Runner wins when it reaches zero
            gs["timer_frames"] = max(0, gs["timer_frames"] - 1)
            if gs["timer_frames"] == 0:
                gs["runner_wins"] = True

        elif gs["chaser_wins"] or gs["runner_wins"]:
            gs["win_frame"] += 1               # drive the pulse animation
            if gs["catch_flash"] > 0:
                gs["catch_flash"] -= 1

        # ── Draw ──────────────────────────────────────────────────────────────

        # Map background
        screen.blit(map_surface, (0, 0))

        # Tsinelas projectiles
        for ts in gs["tsinelas_list"]:
            ts.draw(screen)

        # Runner (Player 1)
        draw_sprite(screen, gs["p1_anim"].current_frame(), gs["x1"], gs["y1"])

        # Chaser (Player 2) — drawn with a red tint while stunned
        chaser_frame = gs["p2_anim"].current_frame()
        if gs["stun_timer"] > 0:
            tinted = chaser_frame.copy()
            tint   = pygame.Surface(tinted.get_size(), pygame.SRCALPHA)
            tint.fill((255, 100, 100, 140))
            tinted.blit(tint, (0, 0), special_flags=pygame.BLEND_RGBA_MULT)
            draw_sprite(screen, tinted, gs["x2"], gs["y2"])
        else:
            draw_sprite(screen, chaser_frame, gs["x2"], gs["y2"])

        # Role labels above each player's head
        r_lbl          = font_hud.render("RUNNER", True, RUNNER_LABEL_COLOR)
        stunned_suffix = " [STUNNED]" if gs["stun_timer"] > 0 else ""
        c_lbl          = font_hud.render("CHASER" + stunned_suffix, True, CHASER_LABEL_COLOR)
        screen.blit(r_lbl, (gs["x1"] - r_lbl.get_width() // 2,
                             gs["y1"] - gs["hh1"] - r_lbl.get_height() - 4))
        screen.blit(c_lbl, (gs["x2"] - c_lbl.get_width() // 2,
                             gs["y2"] - gs["hh2"] - c_lbl.get_height() - 4))

        # Cyan burst on Runner when throwing
        if gs["throw_flash"] > 0:
            alpha = int(160 * gs["throw_flash"] / 10)
            flash = pygame.Surface((gs["hw1"] * 2 + 20, gs["hh1"] * 2 + 20), pygame.SRCALPHA)
            flash.fill((80, 220, 255, alpha))
            screen.blit(flash, (gs["x1"] - gs["hw1"] - 10, gs["y1"] - gs["hh1"] - 10))

        # Yellow burst on Chaser when hit by slipper
        if gs["stun_flash"] > 0:
            alpha = int(200 * gs["stun_flash"] / 20)
            flash = pygame.Surface((gs["hw2"] * 2 + 20, gs["hh2"] * 2 + 20), pygame.SRCALPHA)
            flash.fill((255, 230, 50, alpha))
            screen.blit(flash, (gs["x2"] - gs["hw2"] - 10, gs["y2"] - gs["hh2"] - 10))

        # Red full-screen flash when the Chaser successfully tags the Runner
        if gs["catch_flash"] > 0:
            alpha = int(200 * gs["catch_flash"] / 30)
            flash = pygame.Surface((W, H), pygame.SRCALPHA)
            flash.fill((255, 30, 30, alpha))
            screen.blit(flash, (0, 0))

        # ── HUD — shown only during an active match ───────────────────────────
        if not gs["chaser_wins"] and not gs["runner_wins"]:

            # Survival timer — top center, turns red in the last 10 seconds
            secs_left = gs["timer_frames"] // FPS
            t_color   = TIMER_WARN_COLOR if secs_left <= 10 else TIMER_NORMAL_COLOR
            t_surf    = font_big.render(f"{secs_left // 60}:{secs_left % 60:02d}", True, t_color)
            screen.blit(t_surf, (W // 2 - t_surf.get_width() // 2, 10))

            # Player name labels — bottom-left (Runner) and bottom-right (Chaser)
            n1 = font_hud.render(f"P1: {p1_name}", True, RUNNER_LABEL_COLOR)
            n2 = font_hud.render(f"P2: {p2_name}", True, CHASER_LABEL_COLOR)
            screen.blit(n1, (10, H - n1.get_height() - 50))
            screen.blit(n2, (W - n2.get_width() - 10, H - n2.get_height() - 10))

            # Throw cooldown bar — bottom left corner
            _draw_cd_bar(screen, font_hud, gs["tsinelas_cd"], TSINELAS_CD,
                         "E  Tsinelas", 10, H - 70, bar_w=130, bar_h=14)

            # Controls reminder — bottom center with a semi-transparent background
            tip = font_hud.render(
                "P1 WASD — run  |  E — Tsinelas  |  P2 Arrows — chase  |  ESC to quit",
                True, (220, 220, 220))
            tip_bg = pygame.Surface((tip.get_width() + 14, tip.get_height() + 6), pygame.SRCALPHA)
            tip_bg.fill((0, 0, 0, 110))
            tip_x = W // 2 - tip.get_width() // 2
            tip_y = H - tip.get_height() - 10
            screen.blit(tip_bg, (tip_x - 7, tip_y - 3))
            screen.blit(tip, (tip_x, tip_y))

        # ── Win screen overlay ────────────────────────────────────────────────
        if gs["chaser_wins"]:
            _draw_win_screen(screen, font_big, font_small, gs["win_frame"],
                             p2_name, "Chaser", blurred_bg=blurred_win_bg)
        if gs["runner_wins"]:
            _draw_win_screen(screen, font_big, font_small, gs["win_frame"],
                             p1_name, "Runner — survived!", blurred_bg=blurred_win_bg)

        pygame.display.flip()

    pygame.quit()
    sys.exit()
