# =============================================================================
#  gamemode_select.py — Game Mode Selection Screen
#  Reimagined | Filipino Street Games
# =============================================================================
#
#  Displays two clickable cards — one for each game mode.
#  The player clicks a card to choose their game mode.
#
#  RETURNS:
#    "tumbang_preso"  — player chose Tumbang Preso
#    "habulan"        — player chose Habulan
#    "back"           — player pressed the Back button
#
#  ENTRY POINT:
#    gamemode_select(screen)
#
# =============================================================================

import pygame
import sys
import math

from .back_button import BackButton
from .assets import asset


# =============================================================================
#  GAME MODE DEFINITIONS
# =============================================================================
# Each entry describes one game mode card shown on this screen.
# Add new game modes here to have them appear automatically.

GAME_MODES = [
    {
        "id":          "tumbang_preso",
        "title":       "Tumbang Preso",
        "tagline":     "Knock the can — defend your territory!",
        "description": (
            "P1 (WASD) and E to throw a slipper to hit the can, and Q for Feint.\n"
            "P2 (Arrows) guards the can & blocks the throw.\n"
            "P1 wins by knocking the can.  P2 wins by time."
        ),
        "icon_color":  (220, 160,  50),   # warm gold — used for card accents
        "accent":      (255, 210,  60),   # brighter gold — used on hover
    },
    {
        "id":          "habulan",
        "title":       "Habulan",
        "tagline":     "Chase or escape — 60 seconds on the clock!",
        "description": (
            "P1 (WASD) is the RUNNER, use E to stun P2.\n"
            "P2 (Arrows) is the CHASER.\n"
            "Tag the runner to win.  Survive 60 s to escape!"
        ),
        "icon_color":  ( 80, 200, 100),   # lively green
        "accent":      (120, 240, 130),   # brighter green on hover
    },
]


# =============================================================================
#  ANIMATED ICON HELPER
# =============================================================================

def _draw_icon(surf, mode, cx, cy, size, t):
    """
    Draws a small animated icon representing each game mode.

    surf  — the surface to draw onto
    mode  — the game mode dict from GAME_MODES
    cx/cy — center of the icon area
    size  — bounding box size (px) used to scale internal elements
    t     — current tick counter (drives the animation)
    """

    if mode["id"] == "tumbang_preso":
        # --- Tumbang Preso icon ---
        # Shows: Blue circle (thrower) | Gold dividers | Red circle | Can (green dot)
        GOLD     = (220, 175, 50)
        circ_r   = int(size * 0.20)   # radius for the player circles
        green_r  = int(size * 0.12)   # smaller radius for the can dot
        gap      = int(size * 0.12)   # breathing room between circles and dividers
        slot_w   = int(size * 0.90)   # total horizontal spread of the icon
        line_h   = int(size * 0.52)   # half-height of the divider lines

        # Divider x-positions (divide the icon into three zones)
        div1_x = cx - int(slot_w * 0.28)
        div2_x = cx + int(slot_w * 0.28)

        # Blue circle — bounces left and right in the left zone (simulates throwing)
        lane1_left  = cx - slot_w
        lane1_right = div1_x - circ_r - gap
        blue_travel = lane1_right - (lane1_left + circ_r + gap)
        blue_x = (lane1_left + circ_r + gap) + int(blue_travel * abs(math.sin(t * 0.055)))
        blue_y = cy + int(size * 0.05 * math.sin(t * 0.11))
        pygame.draw.circle(surf, (50, 100, 220), (blue_x, blue_y), circ_r)
        pygame.draw.circle(surf, (120, 160, 255), (blue_x, blue_y), circ_r, 2)

        # Left gold divider line
        pygame.draw.line(surf, GOLD, (div1_x, cy - line_h), (div1_x, cy + line_h), 3)

        # Red circle — bobs up and down in the center zone (simulates the guard)
        red_x = (div1_x + div2_x) // 2
        red_y = cy + int(size * 0.14 * math.sin(t * 0.07 + 1.2))
        pygame.draw.circle(surf, (220, 60, 60), (red_x, red_y), circ_r)
        pygame.draw.circle(surf, (255, 120, 120), (red_x, red_y), circ_r, 2)

        # Right gold divider line
        pygame.draw.line(surf, GOLD, (div2_x, cy - line_h), (div2_x, cy + line_h), 3)

        # Green dot — the tin can, static in the right zone
        green_x = div2_x + (cx + slot_w - div2_x) // 2
        pygame.draw.circle(surf, (60, 200, 80), (green_x, cy), green_r)
        pygame.draw.circle(surf, (120, 240, 130), (green_x, cy), green_r, 2)

    elif mode["id"] == "habulan":
        # --- Habulan icon ---
        # Two circles orbiting each other (one chasing the other)
        ang   = t * 0.07                 # orbit angle, advances each frame
        r_orb = int(size * 0.28)         # orbit radius

        # Calculate positions of the two orbiting circles
        cx1 = cx + int(r_orb * math.cos(ang))
        cy1 = cy + int(r_orb * math.sin(ang))
        cx2 = cx + int(r_orb * math.cos(ang + 1.1))
        cy2 = cy + int(r_orb * math.sin(ang + 1.1))

        # Red circle = Chaser, Green circle = Runner
        pygame.draw.circle(surf, (220,  60,  60), (cx1, cy1), int(size * 0.13))
        pygame.draw.circle(surf, ( 60, 200,  80), (cx2, cy2), int(size * 0.13))

        # Trailing ghost circles behind the Chaser (fading alpha trail)
        for s in range(1, 4):
            a   = ang - s * 0.15
            tx1 = cx + int(r_orb * math.cos(a))
            ty1 = cy + int(r_orb * math.sin(a))
            ghost = pygame.Surface((int(size * 0.26), int(size * 0.26)), pygame.SRCALPHA)
            pygame.draw.circle(ghost, (220, 60, 60, max(0, 80 - s * 25)),
                               (int(size * 0.13), int(size * 0.13)), int(size * 0.09))
            surf.blit(ghost, (tx1 - int(size * 0.13), ty1 - int(size * 0.13)))


# =============================================================================
#  DESCRIPTION TEXT HELPER
# =============================================================================

def _render_desc(screen, text, font, color, card_rect, start_y):
    """
    Renders multi-line description text inside a card, with word wrapping.

    text       — the full description string (use \n for explicit line breaks)
    card_rect  — used to determine the available width for wrapping
    start_y    — y-pixel to start drawing from
    Returns the y position after the last line drawn.
    """
    pad  = 14                          # horizontal padding inside the card
    maxw = card_rect.width - pad * 2   # maximum text width before wrapping

    y = start_y
    for line in text.split("\n"):
        # Word-wrap each explicit line individually
        words = line.split()
        row   = ""
        for word in words:
            test = (row + " " + word).strip()
            if font.size(test)[0] <= maxw:
                row = test
            else:
                if row:
                    s = font.render(row, True, color)
                    screen.blit(s, (card_rect.x + pad, y))
                    y += s.get_height() + 3
                row = word
        if row:
            s = font.render(row, True, color)
            screen.blit(s, (card_rect.x + pad, y))
            y += s.get_height() + 3

    return y


# =============================================================================
#  MAIN ENTRY POINT
# =============================================================================

def gamemode_select(screen):
    """
    Displays the game mode picker and waits for the player to choose.

    Returns:
      "tumbang_preso"  — player clicked the Tumbang Preso card
      "habulan"        — player clicked the Habulan card
      "back"           — player clicked the Back button
    """
    pygame.font.init()
    clock = pygame.time.Clock()
    W, H  = screen.get_size()

    # Shared Back button (top-left corner)
    back_btn = BackButton(screen)

    # ── Fonts ─────────────────────────────────────────────────────────────────
    font_title   = pygame.font.Font(None, max(44, H // 14))   # screen title
    font_mode    = pygame.font.Font(None, max(32, H // 18))   # card mode name
    font_tagline = pygame.font.Font(None, max(20, H // 36))   # card tagline
    font_desc    = pygame.font.Font(None, max(18, H // 42))   # card description
    font_prompt  = pygame.font.Font(None, max(18, H // 42))   # bottom prompt

    # ── Blurred background ────────────────────────────────────────────────────
    # Simulates a soft depth-of-field effect using the start screen image.
    try:
        _bg = pygame.image.load(asset("background_start.png")).convert()
        _bg = pygame.transform.smoothscale(_bg, (W, H))
        _sm = pygame.transform.smoothscale(_bg, (W // 8, H // 8))
        bg  = pygame.transform.smoothscale(_sm, (W, H))
        drk = pygame.Surface((W, H))
        drk.fill((0, 0, 0))
        drk.set_alpha(100)
        bg.blit(drk, (0, 0))
    except Exception:
        bg = None   # graceful fallback if image is missing

    # ── Card layout ───────────────────────────────────────────────────────────
    N      = len(GAME_MODES)            # number of cards to show
    GAP    = int(W * 0.04)             # horizontal gap between and around cards
    CARD_W = int((W - GAP * (N + 1)) / N)
    CARD_H = int(H * 0.60)
    CARD_Y = (H - CARD_H) // 2 + int(H * 0.04)

    # Build one pygame.Rect per card, evenly spaced
    card_rects = [
        pygame.Rect(GAP + i * (CARD_W + GAP), CARD_Y, CARD_W, CARD_H)
        for i in range(N)
    ]

    # Static text surfaces (rendered once, reused every frame)
    title_surf  = font_title.render("Select Game Mode", True, (255, 255, 255))
    title_rect  = title_surf.get_rect(center=(W // 2, int(H * 0.12)))
    prompt_surf = font_prompt.render("Click a mode to continue", True, (180, 180, 180))
    prompt_rect = prompt_surf.get_rect(center=(W // 2, H - int(H * 0.06)))

    # ── Main loop ─────────────────────────────────────────────────────────────
    tick = 0    # frame counter, passed to icon animation
    while True:
        clock.tick(60)
        tick += 1

        # ── Events ───────────────────────────────────────────────────────────
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit(); sys.exit()

            if event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE:
                pygame.quit(); sys.exit()

            if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                # Check Back button first
                if back_btn.clicked(event):
                    return "back"
                # Check each mode card
                for i, rect in enumerate(card_rects):
                    if rect.collidepoint(event.pos):
                        return GAME_MODES[i]["id"]

        mx, my  = pygame.mouse.get_pos()
        hover_i = next((i for i, r in enumerate(card_rects) if r.collidepoint(mx, my)), -1)

        # ── Draw background ───────────────────────────────────────────────────
        screen.blit(bg, (0, 0)) if bg else screen.fill((25, 20, 40))

        # Title and bottom prompt
        screen.blit(title_surf, title_rect)
        screen.blit(prompt_surf, prompt_rect)

        # ── Draw each game mode card ──────────────────────────────────────────
        for i, (mode, rect) in enumerate(zip(GAME_MODES, card_rects)):
            is_hover = (i == hover_i)
            accent   = mode["accent"]
            base_col = mode["icon_color"]

            # Semi-transparent card background — slightly brighter on hover
            card_surf = pygame.Surface((rect.width, rect.height), pygame.SRCALPHA)
            bg_alpha  = 210 if is_hover else 160
            r, g, b   = (45, 38, 70) if is_hover else (35, 28, 55)
            pygame.draw.rect(card_surf, (r, g, b, bg_alpha),
                             pygame.Rect(0, 0, rect.width, rect.height),
                             border_radius=12)
            screen.blit(card_surf, rect.topleft)

            # Card border — brighter accent color on hover
            border_w = 3 if is_hover else 1
            pygame.draw.rect(screen, accent if is_hover else (100, 90, 120),
                             rect, border_w, border_radius=12)

            # Colored stripe at the top of the card (matches each mode's color)
            stripe_h = int(rect.height * 0.04)
            stripe   = pygame.Surface((rect.width - 4, stripe_h), pygame.SRCALPHA)
            pygame.draw.rect(stripe, (*base_col, 200),
                             (0, 0, rect.width - 4, stripe_h), border_radius=6)
            screen.blit(stripe, (rect.x + 2, rect.y + 2))

            # Animated icon in the upper portion of the card
            icon_cy   = rect.y + int(rect.height * 0.28)
            icon_size = int(min(rect.width, rect.height) * 0.30)
            _draw_icon(screen, mode, rect.centerx, icon_cy, icon_size, tick)

            # Mode title — accent color on hover, soft white otherwise
            mode_surf = font_mode.render(
                mode["title"], True, accent if is_hover else (240, 235, 255))
            screen.blit(mode_surf,
                        (rect.centerx - mode_surf.get_width() // 2,
                         icon_cy + icon_size + 10))

            # Tagline below the mode title
            tag_y = icon_cy + icon_size + 10 + mode_surf.get_height() + 4
            tag   = font_tagline.render(mode["tagline"], True, (190, 185, 210))
            if tag.get_width() > rect.width - 16:
                # Scale down if the tagline is too wide for the card
                tag = pygame.transform.smoothscale(tag, (rect.width - 16, tag.get_height()))
            screen.blit(tag, (rect.centerx - tag.get_width() // 2, tag_y))

            # Horizontal divider line separating tagline from description
            div_y = tag_y + tag.get_height() + 10
            pygame.draw.line(screen, (80, 72, 105),
                             (rect.x + 16, div_y), (rect.right - 16, div_y), 1)

            # Description text (word-wrapped inside the card)
            desc_y = div_y + 10
            _render_desc(screen, mode["description"], font_desc,
                         (200, 195, 220), rect, desc_y)

            # "SELECT" badge — only shown on hover (bottom of card)
            if is_hover:
                badge_h = int(rect.height * 0.10)
                badge_y = rect.bottom - badge_h - 10
                badge   = pygame.Surface((rect.width - 30, badge_h), pygame.SRCALPHA)
                pygame.draw.rect(badge, (*base_col, 200),
                                 (0, 0, rect.width - 30, badge_h), border_radius=8)
                bx = rect.x + 15
                screen.blit(badge, (bx, badge_y))
                sel = font_tagline.render("SELECT", True, (20, 15, 35))
                screen.blit(sel, (
                    bx + (rect.width - 30) // 2 - sel.get_width() // 2,
                    badge_y + (badge_h - sel.get_height()) // 2,
                ))

        # Back button is always drawn on top of everything
        back_btn.draw(screen)

        pygame.display.flip()
