"""Asset path resolver.

Every asset lives somewhere under ``assets/`` (images, sprites, audio).
Game code only needs to know a file's *name*; ``asset("can.png")`` returns
the full path no matter which sub-folder it sits in, so the game works
from any working directory.
"""

from pathlib import Path

ASSETS_DIR = Path(__file__).resolve().parent.parent / "assets"

# Anything inside this folder is intentionally ignored by the game.
_IGNORED_DIRS = {"_unused"}

_index = {}


def _build_index():
    for path in ASSETS_DIR.rglob("*"):
        if path.is_file() and not _IGNORED_DIRS.intersection(path.relative_to(ASSETS_DIR).parts):
            _index[path.name] = str(path)


def asset(name):
    """Return the absolute path of the asset called ``name``."""
    if not _index:
        _build_index()
    try:
        return _index[Path(name).name]
    except KeyError:
        raise FileNotFoundError(f"Asset '{name}' not found under {ASSETS_DIR}") from None
