# =============================================================================
#  credits.py — Credits Screen
#  Reimagined | Filipino Street Games
# =============================================================================
#
#  Displays a scrollable credits screen with the full team and personal notes.
#
#  SCROLLING:
#    Mouse wheel       — scroll up / down
#    UP / DOWN arrows  — hold to scroll
#    Auto-scroll       — drifts slowly downward automatically
#
#  EXIT:
#    ESC key or Back button → returns to the previous screen
#
#  ENTRY POINT:
#    show_credits(screen)
#
# =============================================================================

import pygame
import math
from .back_button import BackButton
from .assets import asset


# =============================================================================
#  COLOR PALETTE
# =============================================================================

WHITE    = (255, 255, 255)   # names and general text
GOLD     = (255, 210,  50)   # section headers, titles, quotes
GOLD_DIM = (180, 148,  35)   # divider lines under section headers
GRAY     = (170, 165, 140)   # note/body text
BG_TOP   = ( 15,  12,  30)   # gradient background top color (fallback)
BG_BOT   = ( 35,  25,  55)   # gradient background bottom color (fallback)


# =============================================================================
#  CREDITS CONTENT
# =============================================================================
#
#  Each entry is a dict with a "type" key. Supported types:
#    "spacer"  — adds vertical whitespace
#    "title"   — large gold text (game title, closing message)
#    "section" — bold gold label with an underline rule
#    "name"    — white name entry
#    "note"    — gray body paragraph (auto word-wrapped)
#    "quote"   — gold italic-style quote (auto word-wrapped)
#
# =============================================================================

CREDITS_DATA = [
    {"type": "spacer"},
    {"type": "title",   "text": "REIMAGINED"},
    {"type": "spacer"},
    {"type": "spacer"},

    # ── Production ────────────────────────────────────────────────────────────
    {"type": "section", "text": "PRODUCER"},
    {"type": "name",    "text": "Althea Abalos"},
    {"type": "name",    "text": "Emmanuel A. Cerenio"},
    {"type": "spacer"},

    # ── Art ───────────────────────────────────────────────────────────────────
    {"type": "section", "text": "ART WORKS"},
    {"type": "name",    "text": "Althea Abalos"},
    {"type": "name",    "text": "Emmanuel A. Cerenio"},
    {"type": "name",    "text": "Mikael S. Cerenio"},
    {"type": "spacer"},

    # ── Music ─────────────────────────────────────────────────────────────────
    {"type": "section", "text": "BACKGROUND MUSIC"},
    {"type": "name",    "text": "Emmanuel A. Cerenio"},
    {"type": "name",    "text": "YouTube"},
    {"type": "spacer"},

    # ── Sound Effects ─────────────────────────────────────────────────────────
    {"type": "section", "text": "SFX"},
    {"type": "name",    "text": "Emmanuel A. Cerenio"},
    {"type": "spacer"},
    {"type": "spacer"},

    # ── Althea's Personal Note ────────────────────────────────────────────────
    {"type": "section", "text": "ALTHEA'S NOTE"},
    {"type": "spacer"},
    {
        "type": "note",
        "text": (
            "Forming this project was a fun journey. It started as a silly idea "
            "that I had while taking a shower, which evolved into a game that we "
            "would present as our final project. I faced many obstacles forming "
            "this game, but I'm glad I was able to overcome them. To those "
            "sleepless nights and teary days while creating this project, they "
            "were all worth it."
        ),
    },
    {"type": "spacer"},
    {
        "type": "note",
        "text": (
            "I aspire to create more games similar to this and become a game "
            "developer someday. I hope everyone who plays our game enjoys it "
            "and is happy to share it with others."
        ),
    },
    {"type": "spacer"},
    {"type": "spacer"},

    # ── Emman's Personal Note ─────────────────────────────────────────────────
    {"type": "section", "text": "EMMAN'S NOTE"},
    {"type": "spacer"},
    {
        "type": "note",
        "text": (
            "I never thought that I'd create something to be proud of. "
            "Walking this technological path was not easy, there have been "
            "countless times where I thought to myself \"Is this really what "
            "I want?\" But then one quote struck me:"
        ),
    },
    {"type": "spacer"},
    {
        "type": "quote",
        "text": (
            "\"It does not matter how slow you go, "
            "as long as you do not stop\""
        ),
    },
    {"type": "spacer"},
    {
        "type": "note",
        "text": (
            "I entered this school full of doubts and I'll leave "
            "with many lessons to teach."
        ),
    },
    {"type": "spacer"},
    {
        "type": "note",
        "text": "I am very thankful to the ones who supported me on this project journey:",
    },
    {"type": "spacer"},
    {"type": "name", "text": "Althea Abalos  —  Project Partner"},
    {"type": "name", "text": "Cozmeezer, Fazey, Sammy, Leo, Ken & Lean  —  Online Friends"},
    {"type": "name", "text": "My Loving Parents & Brother"},
    {"type": "name", "text": "Donut & Zesto Grapes  —  Favorite Snacks While Coding"},
    {"type": "name", "text": "John Toffer, Arlie James, Jayan, Shawn, Marco & Eli  —  Friends"},
    {"type": "name", "text": "Remy Rose, James Adrian, Ken Adrian  —  My 3 Half Friends Half Siblings"},
    {"type": "spacer"},
    {
        "type": "note",
        "text": "And lastly, to my love and will always love,",
    },
    {"type": "name",  "text": "Aldea Jeconia"},
    {"type": "spacer"},
    {"type": "spacer"},

    # ── Closing ───────────────────────────────────────────────────────────────
    {"type": "title", "text": "Thank you for playing!"},
    {"type": "spacer"},
    {"type": "spacer"},
]


# =============================================================================
#  WORD-WRAP HELPER
# =============================================================================

def _wrap(text, font, max_width):
    """
    Splits a string into lines that fit within max_width pixels.
    Returns a list of strings, each short enough to render within the limit.
    """
    words = text.split()
    lines = []
    cur   = ""

    for word in words:
        test = (cur + " " + word).strip()
        if font.size(test)[0] <= max_width:
            cur = test
        else:
            if cur:
                lines.append(cur)
            cur = word

    if cur:
        lines.append(cur)

    return lines if lines else [""]


# =============================================================================
#  MAIN ENTRY POINT
# =============================================================================

def show_credits(screen):
    """
    Displays the scrollable credits screen.

    Controls:
      Mouse wheel / UP / DOWN arrows  — scroll content
      ESC or Back button              — return to the previous screen

    Auto-scrolls slowly downward when no keys are held.
    """
    pygame.font.init()
    clock = pygame.time.Clock()
    W, H  = screen.get_size()

    # ── Back button ───────────────────────────────────────────────────────────
    back_btn = BackButton(screen)

    # ── Background ────────────────────────────────────────────────────────────
    # Tries to load the start screen image with a dark overlay.
    # Falls back to a hand-drawn gradient if the file is missing.
    try:
        bg   = pygame.image.load(asset("background_start.png")).convert()
        bg   = pygame.transform.smoothscale(bg, (W, H))
        dark = pygame.Surface((W, H))
        dark.set_alpha(170)
        dark.fill((0, 0, 0))
    except Exception:
        bg   = None
        dark = None

    # ── Fonts ─────────────────────────────────────────────────────────────────
    font_title   = pygame.font.SysFont("Arial", max(52, H // 10),  bold=True)  # game title
    font_section = pygame.font.SysFont("Arial", max(30, H // 20),  bold=True)  # section headers
    font_name    = pygame.font.SysFont("Arial", max(24, H // 26))              # name entries
    font_note    = pygame.font.SysFont("Arial", max(20, H // 30))              # body paragraphs
    font_hint    = pygame.font.SysFont("Arial", max(16, H // 40))              # scroll hint

    # ── Pre-render all content into a flat list ───────────────────────────────
    # Everything is rendered once here, then just blitted in the draw loop.
    # This avoids re-rendering text every frame, which would be expensive.
    TEXT_W   = int(W * 0.70)       # maximum width for wrapped text
    LINE_GAP = int(H * 0.014)      # spacing between lines
    SPACER_H = int(H * 0.042)      # height of blank spacer entries

    # rendered: list of ("surf", surface) | ("rule", width) | ("spacer", height)
    rendered = []

    for entry in CREDITS_DATA:
        t = entry["type"]

        if t == "spacer":
            rendered.append(("spacer", SPACER_H))

        elif t == "title":
            # Large gold title text
            s = font_title.render(entry["text"], True, GOLD)
            rendered.append(("surf", s))
            rendered.append(("spacer", int(LINE_GAP * 0.5)))

        elif t == "section":
            # Bold section header + a decorative underline rule
            s = font_section.render(entry["text"], True, GOLD)
            rendered.append(("surf", s))
            rendered.append(("rule", int(s.get_width() * 1.1)))   # rule slightly wider than text
            rendered.append(("spacer", LINE_GAP))

        elif t == "name":
            # Individual name entry in white
            s = font_name.render(entry["text"], True, WHITE)
            rendered.append(("surf", s))
            rendered.append(("spacer", LINE_GAP))

        elif t == "note":
            # Body paragraph — word-wrapped into gray lines
            for line in _wrap(entry["text"], font_note, TEXT_W):
                s = font_note.render(line, True, GRAY)
                rendered.append(("surf", s))
                rendered.append(("spacer", int(LINE_GAP * 0.5)))
            rendered.append(("spacer", LINE_GAP))

        elif t == "quote":
            # Highlighted quote — word-wrapped in gold
            for line in _wrap(entry["text"], font_section, TEXT_W):
                s = font_section.render(line, True, GOLD)
                rendered.append(("surf", s))
                rendered.append(("spacer", int(LINE_GAP * 0.5)))
            rendered.append(("spacer", LINE_GAP))

    # ── Compute absolute y-positions for every rendered item ──────────────────
    # positions: list of (kind, obj, abs_y)
    positions = []
    cur_y     = int(H * 0.08)   # top padding before the first item

    for item in rendered:
        kind = item[0]
        if kind == "spacer":
            cur_y += item[1]
        elif kind == "surf":
            positions.append(("surf", item[1], cur_y))
            cur_y += item[1].get_height() + 2
        elif kind == "rule":
            positions.append(("rule", item[1], cur_y))
            cur_y += 4

    total_content_h = cur_y + int(H * 0.05)   # total height of all content

    # ── Scroll state ──────────────────────────────────────────────────────────
    scroll_y   = 0                      # current scroll offset (px from top)
    WHEEL_STEP = int(H * 0.05)          # px per mouse wheel tick
    HOLD_SPEED = int(H * 0.006)         # px per frame when arrow key held
    AUTO_SPEED = 0.4                    # px per frame for gentle auto-scroll
    max_scroll = max(0, total_content_h - H)

    held_up   = False
    held_down = False

    # ── Clip region ───────────────────────────────────────────────────────────
    # Content is clipped so it doesn't render over the Back button at the top.
    CLIP_TOP  = back_btn.rect.bottom + 8
    clip_rect = pygame.Rect(0, CLIP_TOP, W, H - CLIP_TOP)

    # ── Vignette fade surfaces ────────────────────────────────────────────────
    # Pre-baked gradient overlays that fade content to black at the top and bottom.
    # This makes the scroll feel smooth and professional.
    FADE_H   = int(H * 0.10)
    fade_top = pygame.Surface((W, FADE_H), pygame.SRCALPHA)
    fade_bot = pygame.Surface((W, FADE_H), pygame.SRCALPHA)
    for i in range(FADE_H):
        alpha = int(255 * (1 - i / FADE_H))
        fade_top.fill((0, 0, 0, alpha), pygame.Rect(0, i, W, 1))
        fade_bot.fill((0, 0, 0, alpha), pygame.Rect(0, FADE_H - 1 - i, W, 1))

    # ── Main loop ─────────────────────────────────────────────────────────────
    while True:
        clock.tick(60)

        # ── Events ───────────────────────────────────────────────────────────
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                raise SystemExit

            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    return                  # back to previous screen
                if event.key == pygame.K_UP:
                    held_up   = True
                if event.key == pygame.K_DOWN:
                    held_down = True

            if event.type == pygame.KEYUP:
                if event.key == pygame.K_UP:
                    held_up   = False
                if event.key == pygame.K_DOWN:
                    held_down = False

            if event.type == pygame.MOUSEWHEEL:
                scroll_y -= event.y * WHEEL_STEP   # positive y = scroll wheel up = content moves up

            if back_btn.clicked(event):
                return                      # back to previous screen

        # ── Scroll update ─────────────────────────────────────────────────────
        # Manual key input takes priority over auto-scroll
        if held_up:
            scroll_y -= HOLD_SPEED
        elif held_down:
            scroll_y += HOLD_SPEED
        else:
            scroll_y += AUTO_SPEED          # gentle automatic downward drift

        scroll_y = max(0, min(scroll_y, max_scroll))   # clamp within bounds

        # ── Draw background ───────────────────────────────────────────────────
        if bg:
            screen.blit(bg,   (0, 0))
            screen.blit(dark, (0, 0))
        else:
            # Fallback: hand-drawn vertical gradient
            for row in range(H):
                t = row / H
                r = int(BG_TOP[0] + (BG_BOT[0] - BG_TOP[0]) * t)
                g = int(BG_TOP[1] + (BG_BOT[1] - BG_TOP[1]) * t)
                b = int(BG_TOP[2] + (BG_BOT[2] - BG_TOP[2]) * t)
                pygame.draw.line(screen, (r, g, b), (0, row), (W, row))

        # ── Draw content (clipped so it doesn't overlap the Back button) ──────
        screen.set_clip(clip_rect)

        for kind, obj, abs_y in positions:
            # Convert absolute content y-position to screen y-position
            draw_y = abs_y - scroll_y + CLIP_TOP

            if draw_y > H + 60:
                continue    # off screen below — skip

            if kind == "surf":
                if draw_y < CLIP_TOP - obj.get_height() - 10:
                    continue    # off screen above — skip
                # Center all text horizontally
                screen.blit(obj, (W // 2 - obj.get_width() // 2, int(draw_y)))

            elif kind == "rule":
                if draw_y < CLIP_TOP - 5:
                    continue
                # Gold underline rule centered on screen
                pygame.draw.line(screen, GOLD_DIM,
                                 (W // 2 - obj // 2, int(draw_y)),
                                 (W // 2 + obj // 2, int(draw_y)), 2)

        screen.set_clip(None)

        # ── Vignette fades (drawn over content, inside the clip zone) ─────────
        screen.blit(fade_top, (0, CLIP_TOP))
        screen.blit(fade_bot, (0, H - FADE_H))

        # ── Scrollbar ─────────────────────────────────────────────────────────
        # Only shown when content is taller than the screen
        if max_scroll > 0:
            SB_W    = 5
            SB_X    = W - SB_W - 6
            SB_TOP  = CLIP_TOP + FADE_H
            SB_H    = H - SB_TOP - FADE_H
            ratio   = scroll_y / max_scroll
            thumb_h = max(30, int(SB_H * (H / total_content_h)))   # proportional thumb
            thumb_y = int(SB_TOP + (SB_H - thumb_h) * ratio)
            pygame.draw.rect(screen, (60, 55, 40),
                             pygame.Rect(SB_X, SB_TOP, SB_W, SB_H), border_radius=3)
            pygame.draw.rect(screen, GOLD_DIM,
                             pygame.Rect(SB_X, thumb_y, SB_W, thumb_h), border_radius=3)

        # ── Back button (always on top) ───────────────────────────────────────
        back_btn.draw(screen)

        # ── Scroll hint at the very bottom ────────────────────────────────────
        hint = font_hint.render(
            "Scroll wheel or Arrow keys to scroll   ·   ESC to go back",
            True, (110, 105, 80),
        )
        screen.blit(hint, (W // 2 - hint.get_width() // 2, H - hint.get_height() - 6))

        pygame.display.flip()
