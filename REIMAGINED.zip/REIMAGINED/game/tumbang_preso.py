# =============================================================================
#  Tumbangpreso.py — Tumbang Preso Game Mode
#  Reimagined | Filipino Street Games
# =============================================================================
#
#  RULES:
#    - Player 1 = THROWER  — throws a slipper to knock over the bouncing can
#    - Player 2 = GUARD    — blocks the slipper to protect the can
#
#  CONTROLS:
#    Player 1 (Thrower)  →  WASD to move  |  Hold E to aim, release to throw
#                           Q + W = teleport to the top half  (Feint ability)
#                           Q + S = teleport to the bottom half
#    Player 2 (Guard)    →  Arrow keys to move
#
#  WIN CONDITIONS:
#    - Player 1 wins  → slipper hits the can
#    - Player 2 wins  → survives the full 60-second timer
#
#  ENTRY POINT:
#    run_tumbang_preso(screen, clock, p1_name, p2_name, p1_char_idx, p2_char_idx)
#
# =============================================================================

import pygame
import sys
import random
import math

from .sprites import can, draw_sprite, Player1Animator, Player2Animator, Tsinelas
from .design import draw_background, map_selection
from .pregame import CHARACTERS
from .sound import play_countdown_audio, play_pregame_music, play_maingame_music, play_tsinelas_throw
from .assets import asset


# =============================================================================
#  CONSTANTS
# =============================================================================

FPS         = 60    # frames per second target
SPEED       = 5     # player movement speed (pixels per frame)
THROW_SPEED = 8     # slipper travel speed  (pixels per frame, scaled at runtime)

# Dashed divider lines drawn on the map to mark zones
BARRIER_WIDTH = 2   # line thickness (px)
DASH_LENGTH   = 15  # length of each dash segment (px)
DASH_GAP      = 8   # gap between dash segments (px)

# Default barrier x-positions (scaled to actual screen size at runtime)
BARRIER_LEFT  = 190
BARRIER_RIGHT = 610

# Feint teleport ability (Q key)
FEINT_COOLDOWN = 90    # frames (~1.5 s at 60 fps)
FEINT_MARGIN   = 150   # minimum px from screen edge after teleporting

# Countdown display: image filenames and how many frames each one stays visible
COUNTDOWN_IMAGES = ["2.png", "3.png", "4.png", "5.png"]   # 3, 2, 1, GO!
STEP_DURATIONS   = [60, 60, 60, 48]                        # frames per image


# =============================================================================
#  BACKGROUND BLUR HELPER
# =============================================================================

def make_blurred_bg(map_surface, W, H):
    """
    Creates a blurred copy of any surface.
    Works by drastically downscaling then upscaling the image.
    Also adds a dark overlay so text drawn on top stays readable.
    Used as the backdrop for the countdown and win screens.
    """
    try:
        src = map_surface.convert()
    except Exception:
        src = map_surface

    small   = pygame.transform.smoothscale(src, (max(1, W // 10), max(1, H // 10)))
    blurred = pygame.transform.smoothscale(small, (W, H))

    dark = pygame.Surface((W, H), pygame.SRCALPHA)
    dark.fill((0, 0, 0, 120))
    blurred.blit(dark, (0, 0))
    return blurred


# =============================================================================
#  COUNTDOWN ANIMATION
# =============================================================================

def load_countdown_frames(H):
    """
    Loads the 3-2-1-GO! images and scales them to 65% of screen height.
    Returns (frames_list, size_tuple).
    """
    size   = (int(H * 0.65), int(H * 0.65))
    frames = []
    for path in COUNTDOWN_IMAGES:
        try:
            img = pygame.image.load(asset(path)).convert()
            img.set_colorkey((0, 0, 0))     # remove black background
            frames.append(pygame.transform.smoothscale(img, size))
        except Exception as e:
            print(f"[countdown] Could not load {path}: {e}")
            frames.append(None)
    return frames, size


def bake_pop_frames(frames, size, levels=8):
    """
    Pre-renders each countdown image at 8 zoom levels (100% to 135% scale).
    This creates the "pop-in" scale-down effect without any math in the draw loop.
    """
    baked = []
    for img in frames:
        zooms = []
        for lvl in range(levels):
            scale = 1.0 + 0.35 * (lvl / (levels - 1))
            if img:
                w = int(size[0] * scale)
                h = int(size[1] * scale)
                zooms.append(pygame.transform.smoothscale(img, (max(1, w), max(1, h))))
            else:
                zooms.append(None)
        baked.append(zooms)
    return baked


def play_countdown(screen, clock, map_surface=None):
    """
    Plays the full 3-2-1-GO! countdown animation over a blurred map background.
    Blocks until the animation finishes, then returns.
    Also plays the countdown audio clip.
    """
    W, H = screen.get_size()
    blurred_bg   = make_blurred_bg(map_surface, W, H) if map_surface else None
    frames, size = load_countdown_frames(H)
    baked        = bake_pop_frames(frames, size)

    play_countdown_audio()

    step       = 0
    step_timer = 0

    while step < len(frames):
        clock.tick(60)

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit(); sys.exit()
            if event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE:
                pygame.quit(); sys.exit()

        # progress: 0.0 → 1.0 across the current step
        progress = step_timer / STEP_DURATIONS[step]

        # Fade out during the final 25% of each step
        fade_alpha = 255 if progress <= 0.75 else int(255 * (1.0 - (progress - 0.75) / 0.25))

        # Pop-in: image starts large, shrinks to normal during the first 25%
        pop_level = int(max(0.0, 1.0 - progress * 4) * 7)

        screen.blit(blurred_bg, (0, 0)) if blurred_bg else screen.fill((20, 20, 35))

        img = baked[step][pop_level]
        if img:
            img.set_alpha(fade_alpha)
            screen.blit(img, (W // 2 - img.get_width() // 2, H // 2 - img.get_height() // 2))

        pygame.display.flip()

        step_timer += 1
        if step_timer >= STEP_DURATIONS[step]:
            step      += 1
            step_timer = 0


# =============================================================================
#  WIN SCREEN
# =============================================================================

def draw_win_screen(screen, font_big, font_small, frame, winner_name, blurred_bg=None):
    """
    Draws the win screen over a blurred map background.

    winner_name  — the winning player's name
    frame        — elapsed frames since win (drives the pulsing scale effect)
    """
    W, H = screen.get_size()

    screen.blit(blurred_bg, (0, 0)) if blurred_bg else screen.fill((10, 10, 25))

    # Dark overlay so the text is clearly readable
    overlay = pygame.Surface((W, H), pygame.SRCALPHA)
    overlay.fill((0, 0, 0, 140))
    screen.blit(overlay, (0, 0))

    # Winner name — slowly pulses in size using a sine wave
    scale = 1.0 + 0.06 * math.sin(frame * 0.1)
    text  = font_big.render(f"{winner_name} Wins!", True, (255, 220, 0))
    tw    = int(text.get_width()  * scale)
    th    = int(text.get_height() * scale)
    screen.blit(pygame.transform.smoothscale(text, (tw, th)),
                (W // 2 - tw // 2, H // 2 - th // 2 - 40))

    # Instructions below the name
    sub = font_small.render("Press R to restart  |  ESC to quit", True, (220, 220, 220))
    screen.blit(sub, (W // 2 - sub.get_width() // 2, H // 2 + th // 2))


# =============================================================================
#  PLAYER MOVEMENT
# =============================================================================

def feint(x, y, keys, half_h, cooldown_timer, screen_h):
    """
    Player 1's teleport ability (Q key).

    Q + W → teleports to the top of the screen
    Q + S → teleports to the bottom of the screen
    Has a cooldown of FEINT_COOLDOWN frames between uses.

    Returns: (new_x, new_y, new_cooldown, did_teleport)
    """
    if cooldown_timer > 0:
        return x, y, cooldown_timer - 1, False     # still on cooldown

    if keys[pygame.K_q]:
        if keys[pygame.K_w]:
            return x, FEINT_MARGIN + half_h, FEINT_COOLDOWN, True    # top
        if keys[pygame.K_s]:
            return x, screen_h - FEINT_MARGIN - half_h, FEINT_COOLDOWN, True  # bottom

    return x, y, cooldown_timer, False


def move_player1(keys, x, y, half_w, half_h, speed, barrier_left, sw, sh, top_y=0):
    """
    Moves Player 1 using WASD.
    Cannot cross the left barrier or leave the screen bounds.
    """
    if keys[pygame.K_w]: y -= speed
    if keys[pygame.K_s]: y += speed
    if keys[pygame.K_a]: x -= speed
    if keys[pygame.K_d]: x += speed

    x = min(x, barrier_left - half_w)              # stop at the left barrier
    x = max(half_w, min(sw - half_w, x))           # clamp horizontally
    y = max(top_y + half_h, min(sh - half_h, y))   # clamp vertically
    return x, y


def move_player2(keys, x, y, half_w, half_h, speed, barrier_left, barrier_right, sh, top_y=0):
    """
    Moves Player 2 using arrow keys.
    Confined to the right zone between barrier_left and barrier_right.
    """
    if keys[pygame.K_UP]:    y -= speed
    if keys[pygame.K_DOWN]:  y += speed
    if keys[pygame.K_LEFT]:  x -= speed
    if keys[pygame.K_RIGHT]: x += speed

    x = max(barrier_left  + half_w, min(barrier_right - half_w, x))  # stay in right zone
    y = max(top_y + half_h, min(sh - half_h, y))                      # clamp vertically
    return x, y


def rects_overlap(ax, ay, aw, ah, bx, by, bw, bh):
    """
    AABB (axis-aligned bounding box) collision check using center positions.
    aw/ah and bw/bh are half-sizes.
    Returns True if the two rectangles overlap.
    """
    return abs(ax - bx) < (aw + bw) and abs(ay - by) < (ah + bh)


# =============================================================================
#  MAIN ENTRY POINT
# =============================================================================

def run_tumbang_preso(screen, clock, p1_name, p2_name, p1_char_idx, p2_char_idx):
    """
    Runs the complete Tumbang Preso game loop.

    Called by main.py after character select.
    Returns when ESC is pressed (back to main menu).
    Press R on the win screen to restart the match.
    """
    SCREEN_WIDTH  = screen.get_width()
    SCREEN_HEIGHT = screen.get_height()

    # Scale barrier positions and speeds to the actual screen resolution
    scale_x       = SCREEN_WIDTH  / 800
    scale_y       = SCREEN_HEIGHT / 600
    barrier_left  = int(BARRIER_LEFT  * scale_x)
    barrier_right = int(BARRIER_RIGHT * scale_x)
    speed_scaled  = int(SPEED       * min(scale_x, scale_y))
    throw_scaled  = int(THROW_SPEED * scale_x)

    font_big   = pygame.font.SysFont("couriernew", 72, bold=True)
    font_small = pygame.font.SysFont("couriernew", 28)

    # ── Map selection (loop until a valid map is chosen) ──────────────────────
    while True:
        map_result = map_selection(screen, clock, SCREEN_WIDTH, SCREEN_HEIGHT)
        if map_result == "back":
            return   # back button → return to main loop → character select
        loader, top_constraint_frac, map_barrier_color = map_result
        break

    _map_surface    = loader(SCREEN_WIDTH, SCREEN_HEIGHT)
    _blurred_win_bg = make_blurred_bg(_map_surface, SCREEN_WIDTH, SCREEN_HEIGHT)

    # Countdown then start in-game music
    play_countdown(screen, clock, map_surface=_map_surface)
    play_maingame_music()

    # ── Game state factory ────────────────────────────────────────────────────
    def reset_game():
        """
        Builds and returns a fresh game-state dictionary.
        Called at match start and whenever R is pressed on the win screen.
        """
        top_y = int(top_constraint_frac * SCREEN_HEIGHT) if top_constraint_frac else 0

        # Create animators for both players using their chosen characters
        p1       = Player1Animator(scale=(96, 96), sprites=CHARACTERS[p1_char_idx]["sprites_p1"])
        hw1, hh1 = p1.get_size()
        hw1 //= 2; hh1 //= 2   # convert to half-sizes for collision

        p2       = Player2Animator(scale=(96, 96), sprites=CHARACTERS[p2_char_idx]["sprites_p2"])
        hw2, hh2 = p2.get_size()
        hw2 //= 2; hh2 //= 2

        start_y = max(SCREEN_HEIGHT // 2, top_y + hh1 + 10)

        return {
            # Map
            "bg":    _map_surface,
            "top_y": top_y,

            # Player 1 (Thrower) — starts just left of the barrier
            "p1_anim": p1,
            "hw1": hw1, "hh1": hh1,
            "x1":  barrier_left - hw1 - 10,
            "y1":  start_y,

            # Player 2 (Guard) — starts in the center of the right zone
            "p2_anim": p2,
            "hw2": hw2, "hh2": hh2,
            "x2":  (barrier_left + barrier_right) // 2,
            "y2":  start_y,

            # The bouncing tin can (starts in the right zone)
            "can_spr": can("can.png", scale=(40, 40)),
            "can_x":   (barrier_right + SCREEN_WIDTH) // 2,
            "can_y":   max(SCREEN_HEIGHT // 2, top_y + 30),
            "can_hw":  20,                                     # can half-size for collision
            "can_dx":  random.choice([-3, -2, 2, 3]),         # random starting velocity
            "can_dy":  random.choice([-3, -2, 2, 3]),

            # Active slipper projectiles
            "tsinelas": [],

            # Input state (used to detect key release for throw)
            "e_was_held":    False,
            "q_was_pressed": False,

            # Feint ability state
            "feint_cd":    0,    # frames remaining on cooldown
            "feint_flash": 0,    # frames of white burst after teleporting

            # Win flags
            "p1_wins":   False,
            "p2_wins":   False,
            "win_frame": 0,      # frames elapsed since win (for pulse animation)

            # Match timer (1 minute)
            "timer_frames": 60 * 60,
        }

    gs = reset_game()

    # ── Main game loop ────────────────────────────────────────────────────────
    running = True
    while running:
        clock.tick(FPS)
        keys   = pygame.key.get_pressed()
        e_held = keys[pygame.K_e]

        # ── Event handling ────────────────────────────────────────────────────
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False

            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    return  # exit to main menu

                # R restarts the match from the win screen
                if event.key == pygame.K_r and (gs["p1_wins"] or gs["p2_wins"]):
                    gs = reset_game()
                    play_countdown(screen, clock, map_surface=_map_surface)
                    play_maingame_music()

        # ── Logic update (only while the match is active) ─────────────────────
        if not gs["p1_wins"] and not gs["p2_wins"]:

            # Feint teleport (Q + W / Q + S)
            q_pressed = keys[pygame.K_q]
            if q_pressed and not gs["q_was_pressed"]:
                gs["x1"], gs["y1"], gs["feint_cd"], did_tp = feint(
                    gs["x1"], gs["y1"], keys, gs["hh1"], gs["feint_cd"], SCREEN_HEIGHT)
                if did_tp:
                    gs["feint_flash"] = 12   # white burst on teleport
            elif gs["feint_cd"] > 0:
                gs["feint_cd"] -= 1
            gs["q_was_pressed"] = q_pressed

            # Throw tsinelas when E is released
            if gs["e_was_held"] and not e_held:
                gs["tsinelas"].append(
                    Tsinelas(gs["x1"], gs["y1"], dx=throw_scaled, dy=0)
                )
                play_tsinelas_throw()    # whoosh sound effect
            gs["e_was_held"] = e_held

            # Move players
            gs["p1_anim"].update(keys)
            gs["p2_anim"].update(keys)
            gs["x1"], gs["y1"] = move_player1(
                keys, gs["x1"], gs["y1"], gs["hw1"], gs["hh1"],
                speed_scaled, barrier_left, SCREEN_WIDTH, SCREEN_HEIGHT, gs["top_y"])
            gs["x2"], gs["y2"] = move_player2(
                keys, gs["x2"], gs["y2"], gs["hw2"], gs["hh2"],
                speed_scaled, barrier_left, barrier_right, SCREEN_HEIGHT, gs["top_y"])

            # Update slipper projectiles
            surviving = []
            for t in gs["tsinelas"]:
                t.update()

                if t.off_screen(SCREEN_WIDTH, SCREEN_HEIGHT):
                    continue    # remove slippers that left the screen

                # Player 2 blocks the slipper — it bounces back to the left
                if rects_overlap(t.x, t.y, 14, 14,
                                 gs["x2"], gs["y2"],
                                 gs["hw2"] * 0.75, gs["hh2"] * 0.75):
                    t.dx = -abs(t.dx)    # reverse direction
                    surviving.append(t)
                    continue

                # Slipper hits the can — Player 1 wins
                if rects_overlap(t.x, t.y, 14, 14,
                                 gs["can_x"], gs["can_y"],
                                 gs["can_hw"], gs["can_hw"]):
                    gs["p1_wins"]  = True
                    gs["tsinelas"] = []
                    break

                surviving.append(t)
            else:
                gs["tsinelas"] = surviving

            # Bounce the can inside the right zone
            gs["can_x"] += gs["can_dx"]
            gs["can_y"] += gs["can_dy"]

            # Bounce off zone boundaries
            if gs["can_x"] - gs["can_hw"] < barrier_right:
                gs["can_x"]  = barrier_right + gs["can_hw"]
                gs["can_dx"] = abs(gs["can_dx"])
            if gs["can_x"] + gs["can_hw"] > SCREEN_WIDTH:
                gs["can_x"]  = SCREEN_WIDTH  - gs["can_hw"]
                gs["can_dx"] = -abs(gs["can_dx"])
            if gs["can_y"] - gs["can_hw"] < gs["top_y"]:
                gs["can_y"]  = gs["top_y"]   + gs["can_hw"]
                gs["can_dy"] = abs(gs["can_dy"])
            if gs["can_y"] + gs["can_hw"] > SCREEN_HEIGHT:
                gs["can_y"]  = SCREEN_HEIGHT - gs["can_hw"]
                gs["can_dy"] = -abs(gs["can_dy"])

            # Match timer — Player 2 wins when it reaches zero
            gs["timer_frames"] = max(0, gs["timer_frames"] - 1)
            if gs["timer_frames"] == 0:
                gs["p2_wins"] = True

        elif gs["p1_wins"] or gs["p2_wins"]:
            gs["win_frame"] += 1   # advance win screen pulse animation

        # ── Draw ──────────────────────────────────────────────────────────────

        # Map background
        draw_background(screen, gs["bg"])

        # Dashed zone divider lines
        dash_start = gs["top_y"] if gs["top_y"] > 0 else 0
        for bx in [barrier_left, barrier_right]:
            dy = dash_start
            while dy < SCREEN_HEIGHT:
                pygame.draw.line(screen, map_barrier_color,
                                 (bx, dy),
                                 (bx, min(dy + DASH_LENGTH, SCREEN_HEIGHT)),
                                 BARRIER_WIDTH)
                dy += DASH_LENGTH + DASH_GAP

        # Top constraint boundary line
        if gs["top_y"] > 0:
            pygame.draw.line(screen, (0, 0, 0),
                             (0, gs["top_y"]), (SCREEN_WIDTH, gs["top_y"]), 3)

        # Player 1
        draw_sprite(screen, gs["p1_anim"].current_frame(), gs["x1"], gs["y1"])

        # Feint flash — white burst at Player 1's position after teleporting
        if gs["feint_flash"] > 0:
            alpha = int(200 * gs["feint_flash"] / 12)
            flash = pygame.Surface((gs["hw1"] * 2 + 20, gs["hh1"] * 2 + 20), pygame.SRCALPHA)
            flash.fill((255, 255, 255, alpha))
            screen.blit(flash, (gs["x1"] - gs["hw1"] - 10, gs["y1"] - gs["hh1"] - 10))
            gs["feint_flash"] -= 1

        # Player 2, bouncing can, active slippers
        draw_sprite(screen, gs["p2_anim"].current_frame(), gs["x2"], gs["y2"])
        draw_sprite(screen, gs["can_spr"], gs["can_x"], gs["can_y"])
        for t in gs["tsinelas"]:
            t.draw(screen)

        # Match timer — top center, turns red in the last 10 seconds
        if not gs["p1_wins"] and not gs["p2_wins"]:
            secs_left = gs["timer_frames"] // 60
            t_color   = (255, 60, 60) if secs_left <= 10 else (255, 255, 255)
            t_surf    = font_big.render(f"{secs_left // 60}:{secs_left % 60:02d}", True, t_color)
            screen.blit(t_surf, (SCREEN_WIDTH // 2 - t_surf.get_width() // 2, 10))

        # Feint cooldown bar — bottom left corner
        bar_x, bar_y, bar_w, bar_h = 20, SCREEN_HEIGHT - 30, 100, 12
        pygame.draw.rect(screen, (180, 180, 180), (bar_x, bar_y, bar_w, bar_h))  # track
        fill      = int(bar_w * (1.0 - gs["feint_cd"] / FEINT_COOLDOWN))
        bar_color = (50, 200, 255) if gs["feint_cd"] == 0 else (100, 120, 200)
        pygame.draw.rect(screen, bar_color, (bar_x, bar_y, fill, bar_h))         # fill
        pygame.draw.rect(screen, (0, 0, 0),  (bar_x, bar_y, bar_w, bar_h), 1)   # border
        lbl = font_small.render("Q  Feint", True, (0, 0, 0))
        screen.blit(lbl, (bar_x, bar_y - lbl.get_height() - 2))

        # Win screen overlay
        if gs["p1_wins"]:
            draw_win_screen(screen, font_big, font_small, gs["win_frame"],
                            p1_name, blurred_bg=_blurred_win_bg)
        if gs["p2_wins"]:
            draw_win_screen(screen, font_big, font_small, gs["win_frame"],
                            p2_name, blurred_bg=_blurred_win_bg)

        pygame.display.flip()
