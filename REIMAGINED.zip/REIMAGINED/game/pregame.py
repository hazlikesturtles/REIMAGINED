import pygame
import sys
import math
from .sprites import (
    ayana_head, franko_head, mara_head,
    rico_head, neneng_ding_head, boyet_kalbo_head,
    ayana_idle, franko_idle, mara_idle,
    rico_idle, neneng_ding_idle, boyet_kalbo_idle,
)
from .assets import asset

# =============================================================================
# CHARACTER ROSTER
# Each entry defines a character's name, head/idle loaders, and sprite files.
# =============================================================================

CHARACTERS = [
    {
        "name": "Ayana",
        "head": ayana_head,
        "idle": ayana_idle,
        "sprites_p1": {
            "walk1":      "ayana_walk1.png",
            "walk2":      "ayana_walk2.png",
            "walk1_left": "ayana_walk1_left.png",
            "walk2_left": "ayana_walk2_left.png",
            "throw":      "anaya_throwing.png",
            "throw_back": "anaya_throwing_back.png",
        },
        "sprites_p2": {
            "walk1":      "ayana_walk1.png",
            "walk2":      "ayana_walk2.png",
            "walk1_left": "ayana_walk1_left.png",
            "walk2_left": "ayana_walk2_left.png",
        },
    },
    {
        "name": "Franko",
        "head": franko_head,
        "idle": franko_idle,
        "sprites_p1": {
            "walk1":      "franko_walk1.png",
            "walk2":      "franko_walk2.png",
            "walk1_left": "franko_walk1_left.png",
            "walk2_left": "franko_walk2_left.png",
            "throw":      "franco_throwing.png",
            "throw_back": "franco_throwing_back.png",
        },
        "sprites_p2": {
            "walk1":      "franko_walk1.png",
            "walk2":      "franko_walk2.png",
            "walk1_left": "franko_walk1_left.png",
            "walk2_left": "franko_walk2_left.png",
        },
    },
    {
        "name": "Mara",
        "head": mara_head,
        "idle": mara_idle,
        "sprites_p1": {
            "walk1":      "mara_walk1.png",
            "walk2":      "mara_walk2.png",
            "walk1_left": "mara_walk1_left.png",
            "walk2_left": "mara_walk2_left.png",
            "throw":      "mara_throwing.png",
            "throw_back": "mara_throwing_back.png",
        },
        "sprites_p2": {
            "walk1":      "mara_walk1.png",
            "walk2":      "mara_walk2.png",
            "walk1_left": "mara_walk1_left.png",
            "walk2_left": "mara_walk2_left.png",
        },
    },
    {
        "name": "Rico",
        "head": rico_head,
        "idle": rico_idle,
        "sprites_p1": {
            "walk1":      "rico_walk1.png",
            "walk2":      "rico_walk2.png",
            "walk1_left": "rico_walk1_left.png",
            "walk2_left": "rico_walk2_left.png",
            "throw":      "rico_throwing.png",
            "throw_back": "rico_throwing_back.png",
        },
        "sprites_p2": {
            "walk1":      "rico_walk1.png",
            "walk2":      "rico_walk2.png",
            "walk1_left": "rico_walk1_left.png",
            "walk2_left": "rico_walk2_left.png",
        },
    },
    {
        "name": "Neneng Ding",
        "head": neneng_ding_head,
        "idle": neneng_ding_idle,
        "sprites_p1": {
            "walk1":      "neneng_ding_walk1.png",
            "walk2":      "neneng_ding_walk2.png",
            "walk1_left": "neneng_ding_walk1_left.png",
            "walk2_left": "neneng_ding_walk2_left.png",
            "throw":      "neneng_ding_throw.png",
            "throw_back": "neneng_ding_throw_back.png",
        },
        "sprites_p2": {
            "walk1":      "neneng_ding_walk1.png",
            "walk2":      "neneng_ding_walk2.png",
            "walk1_left": "neneng_ding_walk1_left.png",
            "walk2_left": "neneng_ding_walk2_left.png",
        },
    },
    {
        "name": "Boyet Kalbo",
        "head": boyet_kalbo_head,
        "idle": boyet_kalbo_idle,
        "sprites_p1": {
            "walk1":      "boyet_kalbo_walk1.png",
            "walk2":      "boyet_kalbo_walk2.png",
            "walk1_left": "boyet_kalbo_walk1_left.png",
            "walk2_left": "boyet_kalbo_walk2_left.png",
            "throw":      "boyet_okalbs_throw.png",
            "throw_back": "boyet_okalbs_throw_back.png",
        },
        "sprites_p2": {
            "walk1":      "boyet_kalbo_walk1.png",
            "walk2":      "boyet_kalbo_walk2.png",
            "walk1_left": "boyet_kalbo_walk1_left.png",
            "walk2_left": "boyet_kalbo_walk2_left.png",
        },
    },
]

# =============================================================================
# COLOURS
# =============================================================================

WHITE     = (255, 255, 255)
BLACK     = (0,   0,   0)
GRAY      = (180, 180, 180)
DARK_GRAY = (80,  80,  80)
HIGHLIGHT = (255, 220, 60)
GREEN     = (80,  180, 80)
BG        = (30,  30,  50)


# =============================================================================
# START SCREEN  (shown first when the game launches)
# =============================================================================

def start_screen(screen):
    """
    'Until Then'-style start screen.
    Left side: game title + Baybayin subtitle + stacked menu buttons.
    Right side: background image fills the screen behind everything.
    Returns the chosen action: 'start', 'credits', or 'quit'.
    """
    pygame.font.init()
    clock = pygame.time.Clock()
    W, H  = screen.get_size()

    # ── Background ────────────────────────────────────────────────────────────
    try:
        bg_img = pygame.image.load(asset("background_start.png")).convert()
        bg_img = pygame.transform.smoothscale(bg_img, (W, H))
    except Exception:
        bg_img = None

    # ── Fonts ─────────────────────────────────────────────────────────────────
    # Title: large, bold, retro-game feel
    TITLE_SIZE = max(52, H // 10)
    try:
        font_title = pygame.font.Font(None, TITLE_SIZE)          # pygame default (clean sans)
    except Exception:
        font_title = pygame.font.SysFont("arial", TITLE_SIZE, bold=True)

    # Menu items
    MENU_SIZE = max(28, H // 20)
    try:
        font_menu = pygame.font.Font(None, MENU_SIZE)
    except Exception:
        font_menu = pygame.font.SysFont("arial", MENU_SIZE, bold=True)

    # ── Menu definition ───────────────────────────────────────────────────────
    MENU_ITEMS = [
        {"label": "START",   "action": "start"},
        {"label": "CREDITS", "action": "credits"},
        {"label": "QUIT",    "action": "quit"},
    ]

    # ── Layout constants ──────────────────────────────────────────────────────
    TITLE_Y      = int(H * 0.12)           # y of the game title
    LEFT_MARGIN  = int(W * 0.06)           # x-start of the text block
    MENU_START_Y = int(H * 0.46)          # y of the first menu item
    MENU_GAP     = int(H * 0.09)          # vertical gap between menu items
    MENU_BLOCK_W = int(W * 0.28)          # width of the clickable menu area

    # ── Baybayin PNG loader ───────────────────────────────────────────────────
    # Load the pre-made baybayin_reimagined.png (transparent background, gold glyphs).
    # Scale it to match the title height so it looks proportional.
    TITLE_SIZE_TMP = max(52, H // 10)
    BAY_TARGET_H   = max(20, int(TITLE_SIZE_TMP * 0.38))
    try:
        _bay_raw  = pygame.image.load(asset("baybayin_reimagined.png")).convert_alpha()
        bay_ratio = _bay_raw.get_width() / _bay_raw.get_height()
        bay_surf  = pygame.transform.smoothscale(
            _bay_raw, (int(BAY_TARGET_H * bay_ratio), BAY_TARGET_H))
    except Exception as e:
        print(f"[start] baybayin PNG not found: {e}")
        bay_surf = None
    BAYBAYIN_H = BAY_TARGET_H

    tick        = 0
    hover_index = -1   # which menu item the mouse is over

    # Pre-render title surface (doesn't change)
    title_surf = font_title.render("REIMAGINED", True, WHITE)

    # Thin decorative line width
    line_w = int(W * 0.30)

    # Thin decorative line under title block
    line_w = int(W * 0.30)

    while True:
        clock.tick(60)
        tick += 1

        mx, my = pygame.mouse.get_pos()
        hover_index = -1

        # Build menu rects this frame (so hover detection is always fresh)
        menu_rects = []
        for i in range(len(MENU_ITEMS)):
            item_y = MENU_START_Y + i * MENU_GAP
            r = pygame.Rect(LEFT_MARGIN - 8, item_y - 4, MENU_BLOCK_W, MENU_SIZE + 8)
            menu_rects.append(r)
            if r.collidepoint(mx, my):
                hover_index = i

        # ── Events ────────────────────────────────────────────────────────────
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit(); sys.exit()

            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    pygame.quit(); sys.exit()
                if event.key in (pygame.K_RETURN, pygame.K_SPACE):
                    return   # treat as START

            if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                for i, r in enumerate(menu_rects):
                    if r.collidepoint(event.pos):
                        action = MENU_ITEMS[i]["action"]
                        if action == "start":
                            return          # proceed to character select
                        elif action == "quit":
                            pygame.quit(); sys.exit()
                        elif action == "credits":
                            from .credits import show_credits
                            show_credits(screen)

        # ── Draw ──────────────────────────────────────────────────────────────
        # Background
        if bg_img:
            screen.blit(bg_img, (0, 0))
        else:
            screen.fill((18, 14, 30))

        # Dark left-side vignette so text is always readable
        vignette = pygame.Surface((int(W * 0.52), H), pygame.SRCALPHA)
        for xi in range(vignette.get_width()):
            alpha = int(200 * (1.0 - xi / vignette.get_width()) ** 0.6)
            pygame.draw.line(vignette, (10, 8, 20, alpha), (xi, 0), (xi, H))
        screen.blit(vignette, (0, 0))

        # ── Title block ───────────────────────────────────────────────────────
        screen.blit(title_surf, (LEFT_MARGIN, TITLE_Y))

        # Baybayin subtitle scaled to exactly match the title's pixel width
        baybayin_y = TITLE_Y + title_surf.get_height() + 4
        if bay_surf:
            title_w   = title_surf.get_width()
            bay_ratio = _bay_raw.get_width() / _bay_raw.get_height()
            bay_h     = int(title_w / bay_ratio)
            bay_big   = pygame.transform.smoothscale(_bay_raw, (title_w, bay_h))
            screen.blit(bay_big, (LEFT_MARGIN, baybayin_y))
            _bay_h_this = bay_h
        else:
            _bay_h_this = 0

        # Thin golden decorative line
        line_y = baybayin_y + _bay_h_this + 10
        pygame.draw.line(screen, (200, 170, 80),
                         (LEFT_MARGIN, line_y),
                         (LEFT_MARGIN + line_w, line_y), 2)

        # ── Menu items ────────────────────────────────────────────────────────
        for i, item in enumerate(MENU_ITEMS):
            item_y   = MENU_START_Y + i * MENU_GAP
            is_hover = (i == hover_index)
            rect     = menu_rects[i]

            # Hover highlight bar
            if is_hover:
                bar = pygame.Surface((rect.width, rect.height), pygame.SRCALPHA)
                bar.fill((255, 220, 80, 40))
                screen.blit(bar, (rect.x, rect.y))

            # Left tick mark on hover
            if is_hover:
                pygame.draw.rect(screen, (255, 220, 80),
                                 pygame.Rect(LEFT_MARGIN - 12, item_y + MENU_SIZE // 4,
                                             4, MENU_SIZE // 2))

            color = (255, 230, 100) if is_hover else (210, 210, 210)
            label = font_menu.render(item["label"], True, color)
            screen.blit(label, (LEFT_MARGIN, item_y))

        pygame.display.flip()


# =============================================================================
# CHARACTER SELECT SCREEN  (shown after start screen)
# =============================================================================

def pregame_screen(screen):
    """
    Shows the character select screen.
    Returns: (p1_name, p2_name, p1_character_index, p2_character_index)
         or  "back"  if the player pressed the Back button.
    """
    from .back_button import BackButton
    back_btn = BackButton(screen)

    pygame.font.init()
    W, H  = screen.get_size()
    clock = pygame.time.Clock()

    # ── Fonts ─────────────────────────────────────────────────────────────────
    font_title = pygame.font.SysFont("Arial", max(30, H // 20), bold=True)
    font_label = pygame.font.SysFont("Arial", max(16, H // 38), bold=True)
    font_input = pygame.font.SysFont("Arial", max(15, H // 42), bold=True)
    font_char  = pygame.font.SysFont("Arial", max(11, H // 58), bold=True)
    font_badge = pygame.font.SysFont("Courier New", max(10, H // 62), bold=True)
    font_start = pygame.font.SysFont("Arial", max(18, H // 30), bold=True)

    # ── Sprite idle images ────────────────────────────────────────────────────
    SPR_H = int(H * 0.13)
    idles = [c["idle"](scale=(SPR_H, SPR_H)) for c in CHARACTERS]

    # ── State ─────────────────────────────────────────────────────────────────
    p1_name      = ""
    p2_name      = ""
    p1_selected  = 0
    p2_selected  = 0
    active_field = "p1"

    p1_box        = pygame.Rect(0, 0, 1, 1)
    p2_box        = pygame.Rect(0, 0, 1, 1)
    start_rect    = pygame.Rect(0, 0, 1, 1)
    p1_head_rects = []
    p2_head_rects = []

    # ── Background ────────────────────────────────────────────────────────────
    try:
        _bg    = pygame.image.load(asset("background_start.png")).convert()
        _bg    = pygame.transform.smoothscale(_bg, (W, H))
        _small = pygame.transform.smoothscale(_bg, (W // 8, H // 8))
        blurred = pygame.transform.smoothscale(_small, (W, H))
        dark = pygame.Surface((W, H)); dark.fill((0,0,0)); dark.set_alpha(80)
        blurred.blit(dark, (0, 0))
        charselect_bg = blurred
    except Exception:
        charselect_bg = None

    # ── Colours ───────────────────────────────────────────────────────────────
    GOLD       = (255, 210, 50)
    GOLD_DIM   = (180, 148, 35)
    WHITE      = (255, 255, 255)
    GRAY       = (170, 165, 140)
    # Cell colours matching the reference: warm tan/brown
    CELL_NORM  = (140, 118, 72)   # unselected cell (lighter warm tan)
    CELL_SEL   = (185, 155, 55)   # selected cell (bright gold)
    CELL_BDR_N = (160, 140, 90)   # unselected border
    CELL_BDR_S = (255, 215, 60)   # selected border (gold)
    NAME_NORM  = (200, 190, 155)  # unselected char name
    NAME_SEL   = (255, 215, 60)   # selected char name

    # ── Layout ────────────────────────────────────────────────────────────────
    PAD      = int(W * 0.016)
    TITLE_H  = int(H * 0.115)
    FOOTER_H = int(H * 0.115)
    PANEL_Y  = TITLE_H
    PANEL_H  = H - TITLE_H - FOOTER_H
    MID_X    = W // 2
    COLS     = 3
    ROWS     = (len(CHARACTERS) + COLS - 1) // COLS

    # ── Key badge helper ──────────────────────────────────────────────────────
    def draw_badge(surf, text, cx, cy):
        bh = int(font_badge.get_height() * 1.6)
        tw = font_badge.size(text)[0]
        bw = max(bh, tw + 8)
        r  = pygame.Rect(cx - bw//2, cy - bh//2, bw, bh)
        # outer shadow
        pygame.draw.rect(surf, (20, 18, 12), r.inflate(2,2), border_radius=4)
        # main key face
        pygame.draw.rect(surf, (65, 60, 45), r, border_radius=4)
        # top highlight
        pygame.draw.line(surf, (110,105,80), (r.x+3, r.y+2), (r.right-4, r.y+2))
        # border
        pygame.draw.rect(surf, (130,120,85), r, 1, border_radius=4)
        t = font_badge.render(text, True, (235, 230, 200))
        surf.blit(t, (r.centerx - t.get_width()//2, r.centery - t.get_height()//2))
        return r

    # ── draw_panel ────────────────────────────────────────────────────────────
    def draw_panel(px, pw, player_label, badges, name_str, selected_idx, is_active, head_rect_list):
        y = PANEL_Y + PAD

        # Player label
        lbl = font_label.render(player_label, True, GOLD)
        screen.blit(lbl, (px + PAD, y))

        # Key badges inline
        bx = px + PAD + lbl.get_width() + PAD // 2
        by = y + lbl.get_height() // 2
        for key in badges:
            r  = draw_badge(screen, key, bx + font_badge.size(key)[0]//2 + 6, by)
            bx = r.right + 3

        y += lbl.get_height() + PAD // 2

        # Name row: "Name:" + input box
        nm_lbl = font_input.render("Name:", True, GRAY)
        screen.blit(nm_lbl, (px + PAD, y + 2))
        box_x = px + PAD + nm_lbl.get_width() + 6
        box_w = pw - PAD - (nm_lbl.get_width() + 6) - PAD
        box_h = nm_lbl.get_height() + 8
        box   = pygame.Rect(box_x, y, box_w, box_h)
        pygame.draw.rect(screen, (30, 26, 18), box, border_radius=3)
        pygame.draw.rect(screen, GOLD if is_active else GOLD_DIM, box, 1, border_radius=3)
        nt = font_input.render(name_str + ("|" if is_active else ""), True, WHITE)
        screen.blit(nt, (box.x + 5, box.y + (box_h - nt.get_height()) // 2))

        y += box_h + PAD

        # ── Character grid ─────────────────────────────────────────────────────
        grid_w  = pw - PAD * 2
        cell_w  = grid_w // COLS
        cell_h  = (PANEL_H - (y - PANEL_Y) - PAD) // ROWS

        head_rect_list.clear()
        for i, idle_img in enumerate(idles):
            col  = i % COLS
            row  = i // COLS
            cx   = px + PAD + col * cell_w
            cy   = y  + row * cell_h
            cell = pygame.Rect(cx + 3, cy + 3, cell_w - 6, cell_h - 6)
            head_rect_list.append(cell)

            is_sel = (i == selected_idx)
            col_bg = CELL_SEL  if is_sel else CELL_NORM
            col_bd = CELL_BDR_S if is_sel else CELL_BDR_N

            cell_surf = pygame.Surface((cell.width, cell.height), pygame.SRCALPHA)
            r,g,b = col_bg
            alpha = 180 if is_sel else 150
            pygame.draw.rect(cell_surf, (r,g,b,alpha),
                             pygame.Rect(0,0,cell.width,cell.height), border_radius=5)
            screen.blit(cell_surf, (cell.x, cell.y))
            pygame.draw.rect(screen, col_bd, cell, 2 if is_sel else 1, border_radius=5)

            # sprite
            nm_surf  = font_char.render(CHARACTERS[i]["name"], True,
                                        NAME_SEL if is_sel else WHITE)
            name_y   = cell.bottom - nm_surf.get_height() - 5
            avail_h  = name_y - cell.y
            sprite_y = cell.y + avail_h // 2 - idle_img.get_height() // 2
            screen.blit(idle_img, (cell.centerx - idle_img.get_width() // 2, sprite_y))
            screen.blit(nm_surf,  (cell.centerx - nm_surf.get_width() // 2, name_y))

        return box

    # ── Main loop ─────────────────────────────────────────────────────────────
    while True:
        clock.tick(60)

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit(); raise SystemExit

            if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                if back_btn.clicked(event):
                    return "back"
                mx, my = event.pos
                if p1_box.collidepoint(mx, my): active_field = "p1"
                if p2_box.collidepoint(mx, my): active_field = "p2"
                for i, r in enumerate(p1_head_rects):
                    if r.collidepoint(mx, my): p1_selected = i; active_field = "p1"
                for i, r in enumerate(p2_head_rects):
                    if r.collidepoint(mx, my): p2_selected = i; active_field = "p2"
                if start_rect.collidepoint(mx, my) and p1_name.strip() and p2_name.strip():
                    return p1_name.strip(), p2_name.strip(), p1_selected, p2_selected

            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    return "back"
                if active_field == "p1":
                    if   event.key == pygame.K_BACKSPACE:               p1_name = p1_name[:-1]
                    elif event.key in (pygame.K_TAB, pygame.K_RETURN):  active_field = "p2"
                    elif len(p1_name) < 16:                             p1_name += event.unicode
                else:
                    if   event.key == pygame.K_BACKSPACE:               p2_name = p2_name[:-1]
                    elif event.key == pygame.K_TAB:                     active_field = "p1"
                    elif event.key == pygame.K_RETURN:
                        if p1_name.strip() and p2_name.strip():
                            return p1_name.strip(), p2_name.strip(), p1_selected, p2_selected
                    elif len(p2_name) < 16:                             p2_name += event.unicode

        # ── Draw ──────────────────────────────────────────────────────────────
        screen.blit(charselect_bg, (0,0)) if charselect_bg else screen.fill((55, 45, 28))

        # Title text
        title_surf = font_title.render("SELECT YOUR CHARACTERS", True, GOLD)
        screen.blit(title_surf, (W//2 - title_surf.get_width()//2,
                                 (TITLE_H - title_surf.get_height()) // 2))
        pygame.draw.line(screen, GOLD_DIM, (0, TITLE_H-1), (W, TITLE_H-1), 2)

        # Panels
        p1_box = draw_panel(0,     MID_X, "PLAYER 1 (WASD)",
                            ["W","A","S","D"],
                            p1_name, p1_selected, active_field=="p1", p1_head_rects)
        p2_box = draw_panel(MID_X, MID_X, "PLAYER 2  (Arrow keys)",
                            ["↑","↓","←","→"],
                            p2_name, p2_selected, active_field=="p2", p2_head_rects)

        # Centre divider
        pygame.draw.line(screen, GOLD_DIM, (MID_X, PANEL_Y), (MID_X, PANEL_Y+PANEL_H), 2)

        # Footer
        footer_y = H - FOOTER_H
        pygame.draw.line(screen, GOLD_DIM, (0, footer_y), (W, footer_y), 2)

        can_start = bool(p1_name.strip() and p2_name.strip())
        btn_w, btn_h = 200, int(FOOTER_H * 0.58)
        mx_c, my_c  = pygame.mouse.get_pos()
        start_rect  = pygame.Rect(W//2 - btn_w//2,
                                  footer_y + (FOOTER_H - btn_h)//2, btn_w, btn_h)
        hovering = start_rect.collidepoint(mx_c, my_c)

        if can_start:
            btn_col = (190, 155, 25) if hovering else (150, 120, 18)
            bdr_col = GOLD
        else:
            btn_col = (55, 50, 35)
            bdr_col = (90, 82, 55)

        pygame.draw.rect(screen, btn_col, start_rect, border_radius=6)
        pygame.draw.rect(screen, bdr_col, start_rect, 1, border_radius=6)

        bt_col = WHITE if can_start else (130, 120, 80)
        bt = font_start.render("START", True, bt_col)
        screen.blit(bt, (start_rect.centerx - bt.get_width()//2,
                         start_rect.centery - bt.get_height()//2))

        # Back button (always on top)
        back_btn.draw(screen)

        pygame.display.flip()
