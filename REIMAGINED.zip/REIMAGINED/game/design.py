# =============================================================================
#  design.py — Map Definitions & Map Selection Screen
#  Reimagined | Filipino Street Games
# =============================================================================
#
#  This module handles everything related to backgrounds and map picking
#  for the Tumbang Preso game mode.
#
#  MAPS AVAILABLE:
#    - Taglagas  (autumn.png)
#    - Kalye     (kalye_background.png)
#    - Lungsod   (City.png)
#
#  Each map stores:
#    - name           → displayed in the map picker
#    - file           → image file used for the thumbnail
#    - loader         → function that loads & scales the background
#    - top_constraint → fraction of screen height players cannot walk above
#    - barrier_color  → color of the dashed zone divider lines
#
# =============================================================================

import pygame
import sys

from .pregame import CHARACTERS
from .assets import asset


# ── Map background loaders ────────────────────────────────────────────────────
# Each function loads its image and scales it to fill the screen exactly.

def autumn_map(width, height):
    """Loads the Taglagas (autumn) background."""
    image = pygame.image.load(asset("autumn.png")).convert()
    return pygame.transform.smoothscale(image, (width, height))

def kalye_map(width, height):
    """Loads the Kalye (street) background."""
    image = pygame.image.load(asset("kalye_background.png")).convert()
    return pygame.transform.smoothscale(image, (width, height))

def city_map(width, height):
    """Loads the Lungsod (city) background."""
    image = pygame.image.load(asset("City.png")).convert()
    return pygame.transform.smoothscale(image, (width, height))


# ── Map roster ────────────────────────────────────────────────────────────────
# Add new maps here. Each entry is a dict with the fields described above.

MAPS = [
    {
        "name":           "Taglagas",
        "file":           "autumn.png",
        "loader":         autumn_map,
        "top_constraint": 0.30,             # players cannot walk above 30% of screen
        "barrier_color":  (255, 255, 255),  # white dashed zone dividers
    },
    {
        "name":           "Kalye",
        "file":           "kalye_background.png",
        "loader":         kalye_map,
        "top_constraint": 0.30,
        "barrier_color":  (255, 255, 255),
    },
    {
        "name":           "Lungsod",
        "file":           "City.png",
        "loader":         city_map,
        "top_constraint": 0.30,
        "barrier_color":  (255, 255, 255),
    },
]


# ── Drawing helpers ───────────────────────────────────────────────────────────

def draw_background(surface, background):
    """Blits the background image at the top-left corner of the surface."""
    surface.blit(background, (0, 0))

def load_background(filename, width, height):
    """Loads any image file and scales it to the given dimensions."""
    image = pygame.image.load(asset(filename)).convert()
    return pygame.transform.scale(image, (width, height))


# ── Map Selection Screen ──────────────────────────────────────────────────────

def map_selection(screen, clock, screen_width, screen_height):
    """
    Shows a fullscreen map picker with thumbnail previews.

    Controls:
      Click a card   → selects that map
      Back button    → returns "back"
      ESC key        → returns "back"

    Returns:
      (loader_function, top_constraint_fraction, barrier_color)
        — the three values needed to set up the chosen map in-game
      "back"
        — if the player pressed Back or ESC
    """
    from .back_button import BackButton
    back_btn = BackButton(screen)

    pygame.font.init()
    font_title = pygame.font.Font(None, 48)
    font_label = pygame.font.Font(None, 22)

    # ── Blurred background (decorative) ──────────────────────────────────────
    # Simulates depth-of-field by downscaling then upscaling the start image.
    try:
        _bg        = pygame.image.load(asset("background_start.png")).convert()
        _bg        = pygame.transform.smoothscale(_bg, (screen_width, screen_height))
        _small     = pygame.transform.smoothscale(_bg, (screen_width // 8, screen_height // 8))
        blurred_bg = pygame.transform.smoothscale(_small, (screen_width, screen_height))
        dark       = pygame.Surface((screen_width, screen_height))
        dark.fill((0, 0, 0))
        dark.set_alpha(80)
        blurred_bg.blit(dark, (0, 0))
    except Exception:
        blurred_bg = None   # graceful fallback if image is missing

    # ── Thumbnail card layout ─────────────────────────────────────────────────
    THUMB_W  = 200   # thumbnail width  (px)
    THUMB_H  = 130   # thumbnail height (px)
    LABEL_H  = 36    # height of the name strip below each thumbnail
    GAP      = 30    # horizontal gap between cards

    # Center all cards horizontally
    total_w = len(MAPS) * THUMB_W + (len(MAPS) - 1) * GAP
    start_x = (screen_width - total_w) // 2
    cards_y = screen_height // 2 - (THUMB_H + LABEL_H) // 2

    # Load thumbnail images (fall back to a gray placeholder if missing)
    thumbs = []
    for m in MAPS:
        try:
            img = pygame.image.load(asset(m["file"])).convert()
            thumbs.append(pygame.transform.smoothscale(img, (THUMB_W, THUMB_H)))
        except Exception:
            surf = pygame.Surface((THUMB_W, THUMB_H))
            surf.fill((200, 200, 200))
            thumbs.append(surf)

    # Build a clickable rect for each card (thumbnail + label strip)
    card_rects = [
        pygame.Rect(start_x + i * (THUMB_W + GAP), cards_y, THUMB_W, THUMB_H + LABEL_H)
        for i in range(len(MAPS))
    ]

    # Title text centered near the top
    title_surf = font_title.render("Pick a Map", True, (255, 255, 255))
    title_rect = title_surf.get_rect(center=(screen_width // 2, screen_height // 4))

    # ── Picker loop ───────────────────────────────────────────────────────────
    selected = None
    while selected is None:
        clock.tick(60)

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()

            if event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE:
                return "back"

            if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                if back_btn.clicked(event):
                    return "back"
                # Check if any map card was clicked
                for i, rect in enumerate(card_rects):
                    if rect.collidepoint(event.pos):
                        selected = (
                            MAPS[i]["loader"],
                            MAPS[i]["top_constraint"],
                            MAPS[i]["barrier_color"],
                        )

        # Detect which card the mouse is hovering over (for highlight effect)
        mx, my  = pygame.mouse.get_pos()
        hover_i = next((i for i, r in enumerate(card_rects) if r.collidepoint(mx, my)), -1)

        # ── Draw ─────────────────────────────────────────────────────────────
        screen.blit(blurred_bg, (0, 0)) if blurred_bg else screen.fill((30, 30, 50))
        screen.blit(title_surf, title_rect)

        for i, (m, rect, thumb) in enumerate(zip(MAPS, card_rects, thumbs)):
            is_hover = (i == hover_i)

            # Thumbnail image (clipped to its portion of the card rect)
            screen.set_clip(pygame.Rect(rect.x, rect.y, THUMB_W, THUMB_H))
            screen.blit(thumb, (rect.x, rect.y))
            screen.set_clip(None)

            # Semi-transparent label strip below the thumbnail
            label_bg = pygame.Surface((THUMB_W, LABEL_H), pygame.SRCALPHA)
            label_bg.fill((0, 0, 0, 140))
            screen.blit(label_bg, (rect.x, rect.y + THUMB_H))

            # Map name centered on the label strip
            label = font_label.render(m["name"], True, (255, 255, 255))
            screen.blit(label, (
                rect.centerx - label.get_width() // 2,
                rect.y + THUMB_H + (LABEL_H - label.get_height()) // 2,
            ))

            # Card border — brighter white on hover
            border_color = (255, 255, 255) if is_hover else (200, 200, 200)
            border_width = 2 if is_hover else 1
            pygame.draw.rect(screen, border_color, rect, border_width)

        # Back button always drawn on top
        back_btn.draw(screen)

        pygame.display.flip()

    return selected
