import pygame
from .assets import asset


# =============================================================================
# HELPERS
# =============================================================================

def _load_alpha(path, scale):
    """Loads an image with alpha support and scales it."""
    img = pygame.image.load(asset(path)).convert_alpha()
    return pygame.transform.scale(img, scale)


def can(image_path, scale=None, bg_color=(0, 0, 0), threshold=30):
    """
    Loads the can image and removes its dark background by making
    near-black pixels transparent.
    """
    image = pygame.image.load(asset(image_path)).convert_alpha()
    if scale:
        image = pygame.transform.scale(image, scale)
    w, h = image.get_size()
    for x in range(w):
        for y in range(h):
            r, g, b, a = image.get_at((x, y))
            if r <= bg_color[0] + threshold and \
               g <= bg_color[1] + threshold and \
               b <= bg_color[2] + threshold:
                image.set_at((x, y), (r, g, b, 0))
    return image


def draw_sprite(surface, image, x, y):
    """Draws an image centered on (x, y)."""
    surface.blit(image, image.get_rect(center=(x, y)))


# =============================================================================
# PLAYER 1 ANIMATOR
# =============================================================================

class Player1Animator:
    """
    Handles Player 1's animation states based on keyboard input.

    States:
      WALK   — alternates walk1/walk2 every WALK_FRAME_DURATION frames
      AIMING — shows throw sprite while E is held
      THROW  — shows throw sprite for THROW_DURATION frames after E is released

    Required sprite keys:
      walk1, walk2             — right-facing walk frames
      walk1_left, walk2_left   — left-facing walk frames
      throw                    — aiming / throw image
    """

    WALK  = "walk"
    AIMING = "aiming"
    THROW = "throw"

    WALK_FRAME_DURATION = 10   # frames per walk step
    THROW_DURATION      = 16   # frames the throw animation plays

    def __init__(self, scale=(96, 96), sprites=None):
        s = sprites or {}
        self.walk1      = _load_alpha(s["walk1"],      scale)
        self.walk2      = _load_alpha(s["walk2"],      scale)
        self.walk1_left = _load_alpha(s["walk1_left"], scale)
        self.walk2_left = _load_alpha(s["walk2_left"], scale)
        self.throw_img  = _load_alpha(s["throw"],      scale)

        self.state         = self.WALK
        self.walk_timer    = 0
        self.walk_frame    = 0      # toggles between 0 and 1
        self.throw_timer   = 0
        self._e_was_held   = False
        self._facing_right = True

    def update(self, keys):
        e_held = keys[pygame.K_e]

        # Update facing direction
        if keys[pygame.K_d]: self._facing_right = True
        if keys[pygame.K_a]: self._facing_right = False

        # State transitions
        if self.state == self.THROW:
            self.throw_timer -= 1
            if self.throw_timer <= 0:
                self.state = self.WALK

        elif e_held:
            self.state = self.AIMING

        elif self._e_was_held and not e_held:
            # E was just released — trigger throw
            self.state       = self.THROW
            self.throw_timer = self.THROW_DURATION

        else:
            self.state = self.WALK
            moving = keys[pygame.K_w] or keys[pygame.K_s] or keys[pygame.K_a] or keys[pygame.K_d]
            if moving:
                self.walk_timer += 1
                if self.walk_timer >= self.WALK_FRAME_DURATION:
                    self.walk_timer = 0
                    self.walk_frame = 1 - self.walk_frame  # toggle frame
            else:
                self.walk_timer = 0
                self.walk_frame = 0  # stand still

        self._e_was_held = e_held

    def current_frame(self):
        """Returns the correct image for the current state and direction."""
        if self.state in (self.AIMING, self.THROW):
            return self.throw_img
        if self._facing_right:
            return self.walk1 if self.walk_frame == 0 else self.walk2
        return self.walk1_left if self.walk_frame == 0 else self.walk2_left

    def get_size(self):
        return self.walk1.get_size()


# =============================================================================
# RUNNER ANIMATOR  (used by Habulan — Q key triggers throw externally)
# =============================================================================

class RunnerAnimator:
    """
    Like Player1Animator but for the Habulan game mode.
    The throw is triggered externally via trigger_throw() (called when Q is pressed)
    rather than by holding/releasing E.

    States:
      WALK  — alternates walk1/walk2 every WALK_FRAME_DURATION frames
      THROW — shows throw sprite for THROW_DURATION frames after trigger_throw()

    Required sprite keys:
      walk1, walk2             — right-facing walk frames
      walk1_left, walk2_left   — left-facing walk frames
      throw                    — right-facing throw image (Habulan only)
      throw_left               — left-facing throw image (Habulan only)
    """

    WALK  = "walk"
    THROW = "throw"

    WALK_FRAME_DURATION = 10
    THROW_DURATION      = 16

    def __init__(self, scale=(96, 96), sprites=None):
        s = sprites or {}
        self.walk1          = _load_alpha(s["walk1"],      scale)
        self.walk2          = _load_alpha(s["walk2"],      scale)
        self.walk1_left     = _load_alpha(s["walk1_left"], scale)
        self.walk2_left     = _load_alpha(s["walk2_left"], scale)
        # throw_back is the left-facing throw sprite (runner throwing behind them)
        # We flip it horizontally for when the runner is facing right
        self.throw_img_left = _load_alpha(s["throw_back"], scale)
        self.throw_img      = pygame.transform.flip(self.throw_img_left, True, False)

        self.state         = self.WALK
        self.walk_timer    = 0
        self.walk_frame    = 0
        self.throw_timer   = 0
        self._facing_right = True

    def trigger_throw(self):
        """Call this when the player presses the throw key (E in Habulan)."""
        self.state       = self.THROW
        self.throw_timer = self.THROW_DURATION

    def update(self, keys):
        # Update facing direction from WASD
        if keys[pygame.K_d]: self._facing_right = True
        if keys[pygame.K_a]: self._facing_right = False

        if self.state == self.THROW:
            self.throw_timer -= 1
            if self.throw_timer <= 0:
                self.state = self.WALK
        else:
            self.state = self.WALK
            moving = keys[pygame.K_w] or keys[pygame.K_s] or keys[pygame.K_a] or keys[pygame.K_d]
            if moving:
                self.walk_timer += 1
                if self.walk_timer >= self.WALK_FRAME_DURATION:
                    self.walk_timer = 0
                    self.walk_frame = 1 - self.walk_frame
            else:
                self.walk_timer = 0
                self.walk_frame = 0

    def current_frame(self):
        if self.state == self.THROW:
            # Use left-facing throw sprite when facing left
            return self.throw_img if self._facing_right else self.throw_img_left
        if self._facing_right:
            return self.walk1 if self.walk_frame == 0 else self.walk2
        return self.walk1_left if self.walk_frame == 0 else self.walk2_left

    def get_size(self):
        return self.walk1.get_size()


# =============================================================================
# PLAYER 2 ANIMATOR
# =============================================================================

class Player2Animator:
    """
    Handles Player 2's walk animation based on arrow key input.
    Faces left by default; flips right when the RIGHT key is pressed.

    Required sprite keys:
      walk1, walk2             — right-facing walk frames
      walk1_left, walk2_left   — left-facing walk frames (default direction)
    """

    WALK_FRAME_DURATION = 10

    def __init__(self, scale=(96, 96), sprites=None):
        s = sprites or {}
        self.walk1_left = _load_alpha(s["walk1_left"], scale)
        self.walk2_left = _load_alpha(s["walk2_left"], scale)
        self.walk1      = _load_alpha(s["walk1"],      scale)
        self.walk2      = _load_alpha(s["walk2"],      scale)

        self.walk_timer    = 0
        self.walk_frame    = 0
        self._facing_right = False  # Player 2 faces left by default

    def update(self, keys):
        # Update facing direction
        if keys[pygame.K_RIGHT]: self._facing_right = True
        if keys[pygame.K_LEFT]:  self._facing_right = False

        moving = keys[pygame.K_UP] or keys[pygame.K_DOWN] or keys[pygame.K_LEFT] or keys[pygame.K_RIGHT]
        if moving:
            self.walk_timer += 1
            if self.walk_timer >= self.WALK_FRAME_DURATION:
                self.walk_timer = 0
                self.walk_frame = 1 - self.walk_frame
        else:
            self.walk_timer = 0
            self.walk_frame = 0

    def current_frame(self):
        """Returns the correct image for the current direction."""
        if self._facing_right:
            return self.walk1 if self.walk_frame == 0 else self.walk2
        return self.walk1_left if self.walk_frame == 0 else self.walk2_left

    def get_size(self):
        return self.walk1_left.get_size()


# =============================================================================
# TSINELAS (THROWN SLIPPER PROJECTILE)
# =============================================================================

class Tsinelas:
    """
    The slipper that Player 1 throws.
    Cycles through 4 rotation frames as it travels across the screen.
    """

    FRAME_SPEED = 4  # frames before switching to the next rotation image

    def __init__(self, x, y, dx, dy, scale=(32, 32)):
        self.x  = float(x)
        self.y  = float(y)
        self.dx = dx
        self.dy = dy

        self.frames = [
            _load_alpha("tsinelas.png",  scale),
            _load_alpha("tsinelas2.png", scale),
            _load_alpha("tsinelas3.png", scale),
            _load_alpha("tsinelas4.png", scale),
        ]
        self.frame_index = 0
        self.frame_timer = 0

    def update(self):
        """Moves the slipper and advances its rotation animation."""
        self.x += self.dx
        self.y += self.dy
        self.frame_timer += 1
        if self.frame_timer >= self.FRAME_SPEED:
            self.frame_timer = 0
            self.frame_index = (self.frame_index + 1) % len(self.frames)

    def draw(self, surface):
        img = self.frames[self.frame_index]
        surface.blit(img, img.get_rect(center=(int(self.x), int(self.y))))

    def off_screen(self, screen_w, screen_h):
        """Returns True if the slipper has gone outside the screen bounds."""
        return self.x < 0 or self.x > screen_w or self.y < 0 or self.y > screen_h


# =============================================================================
# CHARACTER HEAD LOADERS  (used in the character select screen)
# =============================================================================

def ayana_head(scale=(64, 64)):       return _load_alpha("ayana_head.png",       scale)
def franko_head(scale=(64, 64)):      return _load_alpha("franko_head.png",      scale)
def mara_head(scale=(64, 64)):        return _load_alpha("mara_head.png",        scale)
def rico_head(scale=(64, 64)):        return _load_alpha("rico_head.png",        scale)
def neneng_ding_head(scale=(64, 64)): return _load_alpha("neneng_ding_head.png", scale)
def boyet_kalbo_head(scale=(64, 64)): return _load_alpha("boyet_kalbo_head.png", scale)


# =============================================================================
# CHARACTER IDLE LOADERS  (used in the character select screen)
# =============================================================================

def ayana_idle(scale=(80, 80)):       return _load_alpha("ayana_sprite_idle.png",  scale)
def franko_idle(scale=(80, 80)):      return _load_alpha("franko_sprite_idle.png", scale)
def mara_idle(scale=(80, 80)):        return _load_alpha("mara_sprite_idle.png",   scale)
def rico_idle(scale=(80, 80)):        return _load_alpha("rico_sprite_idle.png",   scale)
def neneng_ding_idle(scale=(80, 80)): return _load_alpha("neneng_ding_idle.png",   scale)
def boyet_kalbo_idle(scale=(80, 80)): return _load_alpha("boyet_kalbo_idle.png",   scale)
